import numpy as np
from fig07_multimode import Omega_tanh, phi_tanh, dOmega_tanh, eta_of, omega

def quantities(t,a,b,P):
    Om1=Omega_tanh(t,P['O1'],P['d1']); Om2=Omega_tanh(t,P['O2'],P['d2'])
    e1=eta_of(t,dOmega_tanh,P['d1']);  e2=eta_of(t,dOmega_tanh,P['d2'])
    G1,G2=e1*Om1/4.,e2*Om2/4.
    p1=phi_tanh(t,P['O1'],P['d1']);    p2=phi_tanh(t,P['O2'],P['d2'])
    return Om1,Om2,e1,e2,G1,G2,p1,p2

def rhs(t,a,b,P):
    Om1,Om2,e1,e2,G1,G2,p1,p2=quantities(t,a,b,P)
    fa=-1j*(Om1*a+2*P['U1']*abs(a)**2*a+2*P['U12']*abs(b)**2*a+2*G1*np.cos(2*p1)*np.conj(a))
    fb=-1j*(Om2*b+2*P['U2']*abs(b)**2*b+2*P['U12']*abs(a)**2*b+2*G2*np.cos(2*p2)*np.conj(b))
    return fa,fb

def mu_and_L(t,a,b,P):
    Om1,Om2,e1,e2,G1,G2,p1,p2=quantities(t,a,b,P)
    def f(x):
        aa=x[0]+1j*x[1]; bb=x[2]+1j*x[3]
        fa,fb=rhs(t,aa,bb,P)
        return np.array([fa.real,fa.imag,fb.real,fb.imag])
    x0=np.array([a.real,a.imag,b.real,b.imag]); h=1e-6; J=np.zeros((4,4))
    for i in range(4):
        xp=x0.copy(); xp[i]+=h; xm=x0.copy(); xm[i]-=h
        J[:,i]=(f(xp)-f(xm))/(2*h)
    mu=np.linalg.eigvalsh(0.5*(J+J.T)).max()
    B1=abs(2*P['U1']*a**2+2*G1*np.cos(2*p1)); B2=abs(2*P['U2']*b**2+2*G2*np.cos(2*p2))
    L=max(B1,B2)+4*P['U12']*abs(a)*abs(b)
    return mu, max(e1*Om1,e2*Om2), L

def run(P,T=1000.,dt=0.05):
    a=b=P['a0']+0j; t=0.; out=[]
    for k in range(int(T/dt)):
        out.append((t,)+mu_and_L(t,a,b,P))
        f1a,f1b=rhs(t,a,b,P); f2a,f2b=rhs(t+dt/2,a+dt/2*f1a,b+dt/2*f1b,P)
        f3a,f3b=rhs(t+dt/2,a+dt/2*f2a,b+dt/2*f2b,P); f4a,f4b=rhs(t+dt,a+dt*f3a,b+dt*f3b,P)
        a+=dt/6*(f1a+2*f2a+2*f3a+f4a); b+=dt/6*(f1b+2*f2b+2*f3b+f4b); t+=dt
    return np.array(out)

base=dict(O1=1.00,O2=1.15,d1=0.35,d2=0.30,U1=0.30,U2=0.30,a0=0.02,U12=0.0)
fams={'baseline (Fig.7)':{}, 'U1=U2=0.10':{'U1':0.10,'U2':0.10},
      'U1=0.5,U2=0.15':{'U1':0.50,'U2':0.15}, 'a0=0.05':{'a0':0.05},
      'd1=0.60,d2=0.15':{'d1':0.60,'d2':0.15}}
print(f"{'семейство':>18} {'U12':>5} {'mu<=L':>6} {'зазор L-mu':>11} {'порог mu':>9} {'порог L':>8}")
for nm,ov in fams.items():
    P0=dict(base,**ov)
    r0=run(P0); w=r0[:,2]>0.1*r0[:,2].max()
    thr_mu=thr_L=None
    for U12 in [0.0,0.02,0.05,0.08,0.12,0.2,0.35,0.5]:
        P=dict(P0,U12=U12); r=run(P)
        mu,h,L=r[:,1],r[:,2],r[:,3]
        ok=np.all(mu[w]<=L[w]+1e-12)
        if thr_mu is None and (mu-h)[w].max()>0: thr_mu=U12
        if thr_L  is None and (L-h)[w].max()>0:  thr_L=U12
        if U12 in (0.0,0.2):
            print(f"{nm:>18} {U12:>5.2f} {str(ok):>6} {(L-mu)[w].min():>11.2e}"
                  f" {'':>9} {'':>8}")
    print(f"{nm:>18} {'':>5} {'':>6} {'':>11} {str(thr_mu):>9} {str(thr_L):>8}")
