import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from mm_lib import run, base
U12_fine=[0.0,0.02,0.04,0.06,0.08,0.10,0.15,0.20,0.30,0.40,0.50]
res={u:run(dict(base,U12=u)) for u in set([0.0,0.4])|set(U12_fine)}
t=res[0.0][:,0]; h0=res[0.0][:,2]; w=h0>0.1*h0.max()
dt=t[1]-t[0]; win=int(round(np.pi/dt))          # один период накачки
def env(y):
    n=len(y); out=np.empty(n)
    for i in range(n):
        a=max(0,i-win//2); b=min(n,i+win//2+1); out[i]=y[a:b].max()
    return out

fig,axs=plt.subplots(1,2,figsize=(11.0,4.2))
ax=axs[0]
ax.plot(t[w],h0[w],'k:',lw=2.0,label=r'diagonal horizon  $\max(h_1,h_2)$')
for u,c in [(0.0,'tab:blue'),(0.4,'tab:red')]:
    r=res[u]
    ax.plot(t[w],env(r[:,1])[w],color=c,lw=3.0,alpha=.45,zorder=4,
            label=fr'$\mu_g$,  $U_{{12}}={u}$')
    ax.plot(t[w],env(r[:,3])[w],color=c,lw=1.8,ls=(0,(7,4)),zorder=5,
            label=fr'Eq. (47) bound,  $U_{{12}}={u}$')
ax.set_xlabel(r'time  ($\Omega_0 t$;  $\Omega_0=\omega=1$)')
ax.set_ylabel(r'rate  [$\Omega_0$]')
ax.set_title(r'(a) envelope of $\mu_g$, of the Eq. (47) bound, and the horizon',fontsize=10)
ax.legend(fontsize=8,loc='upper left',framealpha=.92)
ax.grid(alpha=.25,lw=.5)

ax2=axs[1]; ax2.axhline(0,color='0.5',lw=1.)
e_mu=[(res[u][:,1]-res[u][:,2])[w].max() for u in U12_fine]
e_L =[(res[u][:,3]-res[u][:,2])[w].max() for u in U12_fine]
ax2.plot(U12_fine,np.array(e_L)*1e4,'s--',color='tab:green',lw=1.6,ms=5,
         label='Eq. (47) condition')
ax2.plot(U12_fine,np.array(e_mu)*1e4,'o-',color='k',lw=1.6,ms=5,
         label=r'actual  $\mu_g$')
ax2.set_xlabel(r'cross-coupling  $U_{12}$')
ax2.set_ylabel(r'max excess over the horizon  [$10^{-4}\,\Omega_0$]')
ax2.set_title('(b) the condition delimits the domain conservatively',fontsize=10)
ax2.legend(fontsize=9,loc='upper left'); ax2.grid(alpha=.25,lw=.5)
fig.tight_layout(); fig.savefig('fig7_v3.png',dpi=200)
print('ok')
