"""Кандидат в многомодовое условие реализации: оценка по строкам (Гершгорин)
   L_n = |2U_n a_n^2 + 2G_n cos(2phi_n)| + 4 U12 |a||b|
   Проверяем: (1) mu_g <= max_n L_n ?  (2) совпадает ли порог по U12."""
import numpy as np
from fig07_multimode import (Omega_tanh, phi_tanh, dOmega_tanh, eta_of,
                             Omega1_0, Omega2_0, dOmega1, dOmega2, U1, U2, omega)

def rhs(t, a, b, U12):
    Om1=Omega_tanh(t,Omega1_0,dOmega1); Om2=Omega_tanh(t,Omega2_0,dOmega2)
    e1=eta_of(t,dOmega_tanh,dOmega1);   e2=eta_of(t,dOmega_tanh,dOmega2)
    G1,G2=e1*Om1/4.,e2*Om2/4.
    p1=phi_tanh(t,Omega1_0,dOmega1);    p2=phi_tanh(t,Omega2_0,dOmega2)
    fa=-1j*(Om1*a+2*U1*abs(a)**2*a+2*U12*abs(b)**2*a+2*G1*np.cos(2*p1)*np.conj(a))
    fb=-1j*(Om2*b+2*U2*abs(b)**2*b+2*U12*abs(a)**2*b+2*G2*np.cos(2*p2)*np.conj(b))
    return fa,fb

def step_quantities(t,a,b,U12):
    Om1=Omega_tanh(t,Omega1_0,dOmega1); Om2=Omega_tanh(t,Omega2_0,dOmega2)
    e1=eta_of(t,dOmega_tanh,dOmega1);   e2=eta_of(t,dOmega_tanh,dOmega2)
    G1,G2=e1*Om1/4.,e2*Om2/4.
    p1=phi_tanh(t,Omega1_0,dOmega1);    p2=phi_tanh(t,Omega2_0,dOmega2)
    def f(x):
        aa=x[0]+1j*x[1]; bb=x[2]+1j*x[3]
        fa=-1j*(Om1*aa+2*U1*abs(aa)**2*aa+2*U12*abs(bb)**2*aa+2*G1*np.cos(2*p1)*np.conj(aa))
        fb=-1j*(Om2*bb+2*U2*abs(bb)**2*bb+2*U12*abs(aa)**2*bb+2*G2*np.cos(2*p2)*np.conj(bb))
        return np.array([fa.real,fa.imag,fb.real,fb.imag])
    x0=np.array([a.real,a.imag,b.real,b.imag]); h=1e-6
    J=np.zeros((4,4))
    for i in range(4):
        xp=x0.copy(); xp[i]+=h; xm=x0.copy(); xm[i]-=h
        J[:,i]=(f(xp)-f(xm))/(2*h)
    mu=np.linalg.eigvalsh(0.5*(J+J.T)).max()
    B1=abs(2*U1*a**2+2*G1*np.cos(2*p1)); B2=abs(2*U2*b**2+2*G2*np.cos(2*p2))
    cross=4*U12*abs(a)*abs(b)
    L=max(B1,B2)+cross
    return mu, max(e1*Om1,e2*Om2), L, cross, max(B1,B2)

def run(U12,T=1000.,dt=0.05):
    a=b=0.02+0j; t=0.
    out=[]
    for k in range(int(T/dt)):
        out.append((t,)+step_quantities(t,a,b,U12))
        f1a,f1b=rhs(t,a,b,U12); f2a,f2b=rhs(t+dt/2,a+dt/2*f1a,b+dt/2*f1b,U12)
        f3a,f3b=rhs(t+dt/2,a+dt/2*f2a,b+dt/2*f2b,U12); f4a,f4b=rhs(t+dt,a+dt*f3a,b+dt*f3b,U12)
        a+=dt/6*(f1a+2*f2a+2*f3a+f4a); b+=dt/6*(f1b+2*f2b+2*f3b+f4b); t+=dt
    return np.array(out)

r0=run(0.0); h0=r0[:,2]; w=h0>0.1*h0.max()
print(f"{'U12':>5} {'max mu_g':>10} {'max L':>10} {'mu<=L?':>7} {'изб.mu-h':>11} {'изб.L-h':>11}")
for U12 in [0.0,0.05,0.1,0.15,0.2,0.3,0.4,0.5]:
    r=run(U12); t,mu,h,L,cr,B=r[:,0],r[:,1],r[:,2],r[:,3],r[:,4],r[:,5]
    ok=np.all(mu[w]<=L[w]+1e-12)
    print(f"{U12:>5.2f} {mu[w].max():>10.5f} {L[w].max():>10.5f} {str(ok):>7} "
          f"{(mu-h)[w].max():>+11.6f} {(L-h)[w].max():>+11.6f}")
