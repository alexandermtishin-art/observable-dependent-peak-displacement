"""
Split-operator propagation of a parametrically driven particle in a
two-harmonic washboard (or a harmonic control potential).

Units:  mass = 1, Omega_0 = 1.  hbar_eff is an explicit parameter.
    i hbar d_t psi = [ -hbar^2/2 d_xx + V(x,t) ] psi
    V(x,t) = (1 + A cos(w_p t)) * V0(x)

Near the bottom  V0 = 1/2 Om0^2 x^2 - (beta/4) x^4 + ...
so the drive reproduces  Omega^2(t) = Om0^2 (1 + A cos w_p t)  exactly.

Observables
    lam_FT : finite-time growth rate, (1/2) d/dt ln[ max eig Sigma ]
    hbar_h : <h>, h(t) = |dOmega/dt| / Omega   (convention selectable)
    F      : lam_FT / <h>
    P_well : population inside the central well, |x| < x_b
    Gam_esc: -d/dt ln P_well

Harmonic control MUST return  lam_FT = A/4  and  F = pi/8 = 0.392699
under the 'mean' convention.  Run  python propagate.py  to check.
"""
import numpy as np
from lattice import coeffs, V0, barrier

# ----------------------------------------------------------------- grid


def make_grid(L, N):
    x = np.linspace(-L / 2, L / 2, N, endpoint=False)
    dx = x[1] - x[0]
    k = 2 * np.pi * np.fft.fftfreq(N, d=dx)
    return x, dx, k


# ------------------------------------------------------------- potential


def potential(x, kind, U=1 / 24.0, klat=1.0, Om0=1.0):
    """Static part V0(x).  Returns (V0, x_b, info)."""
    if kind == "harmonic":
        return 0.5 * Om0 ** 2 * x ** 2, np.inf, {}
    if kind == "lattice":
        a, b = coeffs(klat, U, Om0)
        Vb, xb = barrier(a, b, klat)
        return V0(x, a, b, klat), xb, {"a": a, "b": b, "V_b": Vb, "x_b": xb}
    raise ValueError(kind)


# -------------------------------------------------------- initial state


def ground_state(x, dx, kk, V, hbar, n_steps=6000, dtau=None):
    """Imaginary-time relaxation to the ground state of the static V."""
    if dtau is None:
        dtau = 0.5 * dx ** 2 / hbar
    psi = np.exp(-0.5 * x ** 2 / hbar) + 0j
    psi /= np.sqrt(np.sum(np.abs(psi) ** 2) * dx)
    eV = np.exp(-0.5 * dtau * V / hbar)
    eK = np.exp(-0.5 * dtau * hbar * kk ** 2)
    for _ in range(n_steps):
        psi = eV * psi
        psi = np.fft.ifft(eK * np.fft.fft(psi))
        psi = eV * psi
        psi /= np.sqrt(np.sum(np.abs(psi) ** 2) * dx)
    return psi


# ------------------------------------------------------------ propagate


def run(kind="lattice", U=1 / 24.0, klat=1.0, hbar=0.125, A=0.10,
        T=400.0, dt=2.0e-3, L=None, N=None, Om0=1.0,
        n_sample=400, init="ground"):
    w_p = 2.0 * Om0

    if L is None:
        L = 6 * (2 * np.pi / klat) if kind == "lattice" else 40.0
    if N is None:
        N = 4096
    x, dx, kk = make_grid(L, N)
    Vst, x_b, info = potential(x, kind, U, klat, Om0)

    if init == "ground":
        psi = ground_state(x, dx, kk, Vst, hbar)
    else:                                   # harmonic vacuum
        s = np.sqrt(hbar / (2 * Om0))
        psi = np.exp(-x ** 2 / (4 * s ** 2)) + 0j
        psi /= np.sqrt(np.sum(np.abs(psi) ** 2) * dx)

    eK_half = np.exp(-0.5j * dt * (hbar * kk ** 2) / 2.0)

    n_t = int(round(T / dt))
    stride = max(1, n_t // n_sample)
    ts, sig, pw = [], [], []

    def observe(t, psi):
        rho = np.abs(psi) ** 2
        nrm = np.sum(rho) * dx
        xm = np.sum(x * rho) * dx / nrm
        x2 = np.sum(x ** 2 * rho) * dx / nrm
        ph = np.fft.fft(psi)
        pk = hbar * kk
        rp = np.abs(ph) ** 2
        rp /= np.sum(rp)
        pm = np.sum(pk * rp)
        p2 = np.sum(pk ** 2 * rp)
        # <xp+px>/2 via  hbar * Im( conj(psi) d_x psi )  -> symmetric covariance
        dpsi = np.fft.ifft(1j * kk * np.fft.fft(psi))
        xp = np.sum(x * hbar * np.imag(np.conj(psi) * dpsi)) * dx / nrm
        S = np.array([[x2 - xm ** 2, xp - xm * pm],
                      [xp - xm * pm, p2 - pm ** 2]])
        ev = np.linalg.eigvalsh(S)
        pw_ = (np.sum(rho[np.abs(x) < x_b]) * dx / nrm) if np.isfinite(x_b) else 1.0
        return max(ev.max(), 1e-300), pw_

    s0, p0 = observe(0.0, psi)
    ts.append(0.0); sig.append(s0); pw.append(p0)

    for n in range(n_t):
        t = n * dt
        psi = np.fft.ifft(eK_half * np.fft.fft(psi))
        Vt = (1.0 + A * np.cos(w_p * (t + 0.5 * dt))) * Vst
        psi = np.exp(-1j * dt * Vt / hbar) * psi
        psi = np.fft.ifft(eK_half * np.fft.fft(psi))
        if (n + 1) % stride == 0:
            s, p = observe(t + dt, psi)
            ts.append(t + dt); sig.append(s); pw.append(p)

    return (np.array(ts), np.array(sig), np.array(pw),
            dict(info, L=L, N=N, dx=dx, hbar=hbar, A=A, klat=klat, x_b=x_b))


# ---------------------------------------------------------- observables


def h_bar(A, T0, T1, Om0=1.0, convention="mean", n=200001):
    """<h> with h = |dOmega/dt|/Omega, Omega = Om0 sqrt(1 + A cos w_p t)."""
    w_p = 2.0 * Om0
    t = np.linspace(T0, T1, n)
    Om = Om0 * np.sqrt(1.0 + A * np.cos(w_p * t))
    h = np.abs(np.gradient(Om, t)) / Om
    if convention == "mean":
        return np.trapezoid(h, t) / (T1 - T0)
    if convention == "rms":
        return np.sqrt(np.trapezoid(h ** 2, t) / (T1 - T0))
    raise ValueError(convention)


def fit_rate(ts, y, f0=0.30, f1=0.85, log=True):
    T = ts[-1]
    m = (ts > f0 * T) & (ts < f1 * T)
    yy = np.log(y[m]) if log else y[m]
    c, cov = np.polyfit(ts[m], yy, 1, cov=True)
    resid = yy - np.polyval(c, ts[m])
    ss = 1 - np.sum(resid ** 2) / np.sum((yy - yy.mean()) ** 2)
    return c[0], np.sqrt(cov[0, 0]), ss


def analyse(ts, sig, pw, A, f0=0.30, f1=0.85, convention="mean", Om0=1.0):
    sl, err, r2 = fit_rate(ts, sig)
    lam = 0.5 * sl                     # sigma ~ e^{2 lam t}
    hb = h_bar(A, f0 * ts[-1], f1 * ts[-1], Om0, convention)
    out = {"lam_FT": lam, "lam_err": 0.5 * err, "R2": r2,
           "h_bar": hb, "F": lam / hb, "convention": convention}
    if np.any(pw < 0.999):
        sl2, e2, r22 = fit_rate(ts, np.maximum(pw, 1e-12))
        out.update({"Gam_esc": -sl2, "Gam_err": e2, "R2_esc": r22,
                    "P_well_end": pw[-1]})
    else:
        out.update({"Gam_esc": 0.0, "P_well_end": pw[-1]})
    return out


# ------------------------------------------------------------ self-test
if __name__ == "__main__":
    print("=== КОНТРОЛЬ: гармонический потенциал ===")
    print("ожидается lam_FT = A/4 и F = pi/8 = 0.392699\n")
    for A in [0.05, 0.10, 0.20]:
        ts, sig, pw, inf = run(kind="harmonic", hbar=0.125, A=A,
                               T=300.0, dt=1e-3, L=60.0, N=4096,
                               init="vacuum")
        r = analyse(ts, sig, pw, A)
        print(f"  A={A:<5} lam={r['lam_FT']:.6f}  A/4={A/4:.6f}  "
              f"F={r['F']:.5f}  R2={r['R2']:.6f}")
    print(f"\n  pi/8 = {np.pi/8:.6f}   1/sqrt(8) = {1/np.sqrt(8):.6f}")
