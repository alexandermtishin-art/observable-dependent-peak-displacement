"""
Two-harmonic washboard with INDEPENDENT (|U|, well depth) axes.

    V0(x) = a[1-cos(kx)] + b[1-cos(2kx)]
    V(x,t) = (1 + A cos(wp t)) * V0(x)

Near x=0:  V0 = 1/2 Om0^2 x^2 - (beta/4) x^4 + O(x^6)
    Om0^2 = k^2 (a + 4b)
    beta   = k^4 (a + 16b)/6 ,   |U| = beta/(4 Om0^2)

Fix Om0=1 and |U|; then k is a FREE axis controlling barrier height.
"""
import numpy as np
from scipy.optimize import brentq

def coeffs(k, U, Om0=1.0):
    """Solve a,b from  k^2(a+4b)=Om0^2  and  k^4(a+16b)/24 = U*Om0^2."""
    s1 = Om0**2 / k**2          # a + 4b
    s2 = 24*U*Om0**2 / k**4     # a + 16b
    b = (s2 - s1)/12.0
    a = s1 - 4*b
    return a, b

def V0(x, a, b, k):
    return a*(1-np.cos(k*x)) + b*(1-np.cos(2*k*x))

def barrier(a, b, k):
    """Height and position of the first maximum of V0 for x>0."""
    xs = np.linspace(1e-6, np.pi/k, 200001)
    v = V0(xs, a, b, k)
    i = np.argmax(v)
    # refine on dV=0
    dV = lambda x: a*k*np.sin(k*x) + 2*b*k*np.sin(2*k*x)
    lo, hi = xs[max(i-2,0)], xs[min(i+2,len(xs)-1)]
    try:
        xb = brentq(dV, lo, hi) if dV(lo)*dV(hi) < 0 else xs[i]
    except ValueError:
        xb = xs[i]
    return V0(xb, a, b, k), xb

def check_expansion(a, b, k, U, Om0=1.0):
    """Numerically verify Om0 and |U| from the Taylor coefficients."""
    x = np.linspace(-0.02, 0.02, 2001)
    c = np.polyfit(x, V0(x, a, b, k), 6)     # even function
    Om2 = 2*c[4]                              # coeff of x^2 = Om0^2/2
    beta = -4*c[2]                            # coeff of x^4 = -beta/4
    return np.sqrt(Om2), beta/(4*Om2)

if __name__ == "__main__":
    U = 1/24
    print(f"|U| = {U:.6f}  (Om0 = 1)\n")
    print(f"{'k':>6} {'a':>10} {'b':>10} {'V_b':>9} {'x_b':>8} "
          f"{'N_b(h=.125)':>12} {'Om0_chk':>8} {'U_chk':>9}")
    for k in [0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90]:
        a, b = coeffs(k, U)
        Vb, xb = barrier(a, b, k)
        o, u = check_expansion(a, b, k, U)
        print(f"{k:>6.2f} {a:>10.4f} {b:>10.4f} {Vb:>9.4f} {xb:>8.3f} "
              f"{Vb/0.125:>12.2f} {o:>8.5f} {u:>9.6f}")
