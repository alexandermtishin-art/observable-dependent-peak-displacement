import numpy as np
from lattice import coeffs, V0, barrier, check_expansion

U=1/24
print(f"{'k':>6} {'a':>9} {'b':>9} {'V_b':>8} {'x_b':>7} {'ям на 2pi/k':>6}  shape")
for k in [0.20,0.25,0.30,0.40,0.50,0.60,0.70,0.75,0.80,1.00,1.30,1.60,2.00]:
    a,b=coeffs(k,U); Vb,xb=barrier(a,b,k)
    xs=np.linspace(-3*np.pi/k,3*np.pi/k,60001); v=V0(xs,a,b,k)
    # is x=0 a local min and is V>=0 nearby?
    ok = (v[len(v)//2] <= v[len(v)//2+50]) and np.isfinite(Vb)
    # count distinct local minima over one period of the composite (2pi/k)
    per=(xs>=0)&(xs<2*np.pi/k)
    vv=v[per]; mins=np.sum((vv[1:-1]<vv[:-2])&(vv[1:-1]<vv[2:]))
    print(f"{k:>6.2f} {a:>9.3f} {b:>9.3f} {Vb:>8.4f} {xb:>7.3f} {mins:>6}  {'ok' if ok else 'BAD'}")
