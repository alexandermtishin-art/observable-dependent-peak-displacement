"""
Трансмон в зарядовом базисе (компактная фаза), как у Cohen/Shillito.
H~ = -(h^2/2) d_phi^2 + (1-cos phi) + eps~ cos(w_d t) n̂ ,  h = sqrt(8 E_C/E_J)
n̂ = -i d_phi  -> целые k. Ионизация = населённость состояний с E > V_b = 2.
"""
import numpy as np

def build(EJ_EC, N=256):
    hb=np.sqrt(8.0/EJ_EC)
    phi=np.linspace(0,2*np.pi,N,endpoint=False); dphi=phi[1]-phi[0]
    k=np.fft.fftfreq(N,d=dphi)*2*np.pi          # целые
    V=1-np.cos(phi)
    Kin=np.real(np.fft.ifft(np.diag(0.5*hb**2*k**2)@np.fft.fft(np.eye(N),axis=0),axis=0))
    H=(Kin+np.diag(V)); H=(H+H.T)/2
    E,U=np.linalg.eigh(H)
    return hb,phi,dphi,k,V,E,U

def run(EJ_EC=50.,eps=0.25,wd=0.9,T=150.,dt=2e-3,N=256,n_sample=300):
    hb,phi,dphi,k,V,E,U=build(EJ_EC,N)
    s=np.sqrt(hb/2.)
    psi=np.exp(-((phi-np.pi)**2)/(4*s**2)); psi=np.roll(psi,N//2)  # центр в phi=0
    psi=psi.astype(complex); psi/=np.sqrt(np.sum(np.abs(psi)**2)*dphi)
    above=E>2.0
    eV=np.exp(-1j*dt*V/hb)
    n_t=int(round(T/dt)); stride=max(1,n_t//n_sample)
    ts,ion,en=[0.],[],[]
    def obs(psi):
        c=(U.T@psi)*np.sqrt(dphi); w=np.abs(c)**2; w/=w.sum()
        return w[above].sum(), float(np.sum(w*E))
    a,b=obs(psi); ion.append(a); en.append(b)
    for i in range(n_t):
        t=i*dt
        ph=np.exp(-0.5j*dt*(0.5*hb**2*k**2 + eps*np.cos(wd*(t+0.5*dt))*k)/hb)
        psi=np.fft.ifft(ph*np.fft.fft(psi)); psi=eV*psi
        psi=np.fft.ifft(ph*np.fft.fft(psi))
        if (i+1)%stride==0:
            a,b=obs(psi); ts.append(t+dt); ion.append(a); en.append(b)
    return np.array(ts),np.array(ion),np.array(en),hb,E,above.sum()

if __name__=="__main__":
    print('сходимость по N (EJ/EC=50, eps=0.25, wd=0.9)')
    for N in [128,256,512]:
        t,ion,en,hb,E,na=run(N=N)
        print(f'  N={N:>4}  h_eff={hb:.4f}  связанных={np.sum(E<2)}  ионизация(T)={ion[-1]:.4f}  E(T)={en[-1]:.4f}')
