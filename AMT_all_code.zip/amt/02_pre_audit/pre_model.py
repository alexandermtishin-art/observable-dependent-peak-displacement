"""
Exact reproduction of the PRE manuscript's model.

    H = p^2/2 + (1/2) Om^2(t) x^2 + (beta/4) x^4      (confining / hardening)
    Om^2(t) = Om0^2 (1 + A cos(w_p t)),  w_p = 2 Om0
    |U| = beta/(4 Om0^2) = 1/24  ->  beta = 1/6
    xi = eta/|U| = 3  ->  eta = 0.125  ->  A = 0.125

    h = eta*Om ;  <h> = TIME-MEAN of h over the fitting window  (manuscript §II)
    lam = secular slope of ln sigma_max, sigma_max period-averaged first
    F = lam/<h>          harmonic control must give pi/8 = 0.392699

Two initial-state protocols:
    'as_published' : quantum = imaginary-time ground state of the static well
                     classical = harmonic vacuum Gaussian (Var = hbar/2)
    'matched'      : both = harmonic vacuum Gaussian
"""
import numpy as np

Om0 = 1.0
U = 1/24.
BETA = 4*U          # 1/6
A_DRIVE = 0.125
WP = 2*Om0


def make_grid(L, N):
    x = np.linspace(-L/2, L/2, N, endpoint=False)
    dx = x[1]-x[0]
    k = 2*np.pi*np.fft.fftfreq(N, d=dx)
    return x, dx, k


def Vstatic(x, sign=+1):
    return 0.5*Om0**2*x**2 + sign*(BETA/4)*x**4


def ground_state(x, dx, kk, V, hb, n=20000):
    dtau = 0.4*dx**2/hb
    psi = np.exp(-x**2/(2*hb)) + 0j
    psi /= np.sqrt(np.sum(np.abs(psi)**2)*dx)
    eV = np.exp(-0.5*dtau*V/hb)
    eK = np.exp(-0.5*dtau*hb*kk**2)
    for _ in range(n):
        psi = eV*psi
        psi = np.fft.ifft(eK*np.fft.fft(psi))
        psi = eV*psi
        psi /= np.sqrt(np.sum(np.abs(psi)**2)*dx)
    return psi


def quantum(hb, init='ground', sign=+1, T=150., dt=2e-3, L=48., N=4096, n_sample=3000):
    x, dx, kk = make_grid(L, N)
    V = Vstatic(x, sign)
    if init == 'ground':
        psi = ground_state(x, dx, kk, V, hb)
    else:
        s = np.sqrt(hb/2.)
        psi = np.exp(-x**2/(4*s**2)) + 0j
        psi /= np.sqrt(np.sum(np.abs(psi)**2)*dx)
    eK = np.exp(-0.5j*dt*(hb*kk**2)/2.)
    n_t = int(round(T/dt)); stride = max(1, n_t//n_sample)
    ts, sg = [], []

    def sigma(psi):
        rho = np.abs(psi)**2; nrm = np.sum(rho)*dx
        xm = np.sum(x*rho)*dx/nrm; x2 = np.sum(x**2*rho)*dx/nrm
        dpsi = np.fft.ifft(1j*kk*np.fft.fft(psi))
        p2 = np.sum(hb**2*np.abs(dpsi)**2)*dx/nrm
        pm = np.sum(hb*np.imag(np.conj(psi)*dpsi))*dx/nrm
        xp = np.sum(x*hb*np.imag(np.conj(psi)*dpsi))*dx/nrm
        S = np.array([[x2-xm**2, xp-xm*pm], [xp-xm*pm, p2-pm**2]])
        return max(np.linalg.eigvalsh(S).max(), 1e-300)

    ts.append(0.); sg.append(sigma(psi))
    for i in range(n_t):
        t = i*dt
        psi = np.fft.ifft(eK*np.fft.fft(psi))
        psi = np.exp(-1j*dt*(0.5*Om0**2*(1+A_DRIVE*np.cos(WP*(t+0.5*dt)))*x**2
                             + np.sign(sign)*(BETA/4)*x**4)/hb)*psi
        psi = np.fft.ifft(eK*np.fft.fft(psi))
        if (i+1) % stride == 0:
            ts.append(t+dt); sg.append(sigma(psi))
    return np.array(ts), np.array(sg)


def classical(hb, sign=+1, T=150., dt=4e-3, n_traj=4000, seed=3, n_sample=3000):
    rng = np.random.default_rng(seed)
    s = np.sqrt(hb/2.)
    x = rng.normal(0, s, n_traj); p = rng.normal(0, s, n_traj)
    n_t = int(round(T/dt)); stride = max(1, n_t//n_sample)
    ts, sg = [0.], []

    def sigma(x, p):
        S = np.cov(np.vstack([x, p]))
        return max(np.linalg.eigvalsh(S).max(), 1e-300)
    sg.append(sigma(x, p))
    for i in range(n_t):
        t = i*dt
        f = -(Om0**2*(1+A_DRIVE*np.cos(WP*t))*x + np.sign(sign)*BETA*x**3)
        p += 0.5*dt*f; x += dt*p
        f = -(Om0**2*(1+A_DRIVE*np.cos(WP*(t+dt)))*x + np.sign(sign)*BETA*x**3)
        p += 0.5*dt*f
        if (i+1) % stride == 0:
            ts.append(t+dt); sg.append(sigma(x, p))
    return np.array(ts), np.array(sg)


def period_average(ts, sg):
    """Average sigma over one drive period (manuscript §III)."""
    Tp = 2*np.pi/WP
    out_t, out_s = [], []
    i = 0
    while ts[i] + Tp <= ts[-1]:
        m = (ts >= ts[i]) & (ts < ts[i]+Tp)
        if m.sum() > 2:
            out_t.append(ts[m].mean()); out_s.append(sg[m].mean())
        i += max(1, m.sum())
    return np.array(out_t), np.array(out_s)


def h_mean(t0, t1, n=400001):
    t = np.linspace(t0, t1, n)
    Om = Om0*np.sqrt(1 + A_DRIVE*np.cos(WP*t))
    h = np.abs(np.gradient(Om, t))/Om0            # eta*Om with omega ~ Om0
    return np.trapezoid(h, t)/(t1-t0)


def extract_F(ts, sg, frac_end=0.60):
    """Window ends before sigma_max reaches 60% of its maximum (W3); fit ln sigma."""
    ta, sa = period_average(ts, sg)
    smax = sa.max()
    idx = np.where(sa >= frac_end*smax)[0]
    iend = idx[0] if len(idx) else len(sa)-1
    ist = 1
    if iend - ist < 5:
        return np.nan, np.nan, np.nan
    t, y = ta[ist:iend], np.log(sa[ist:iend])
    c = np.polyfit(t, y, 1)
    r = y - np.polyval(c, t)
    r2 = 1 - np.sum(r**2)/np.sum((y-y.mean())**2)
    lam = 0.5*c[0]
    return lam/h_mean(t[0], t[-1]), r2, lam
