"""Тест факторизации F = K_waveform x P_dynamics.
   K берётся из гармонического случая при той же форме накачки."""
import numpy as np, sys
import pre_model as M

WF={'cos':np.cos,'square':lambda th:np.sign(np.cos(th)),
    'tri':lambda th:2/np.pi*np.arcsin(np.cos(th))}

def hbar_wf(f,A,t0,t1,n=800001):
    t=np.linspace(t0,t1,n)
    Om=np.sqrt(np.maximum(1+A*f(M.WP*t),1e-12))
    return np.trapezoid(np.abs(np.gradient(Om,t))/Om,t)/(t1-t0)

def quantum_wf(f,hb,beta,A,T,dt=2e-3,L=48.,N=2048,n_sample=3000):
    x,dx,kk=M.make_grid(L,N)
    s=np.sqrt(hb/2.); psi=np.exp(-x**2/(4*s**2))+0j
    psi/=np.sqrt(np.sum(np.abs(psi)**2)*dx)
    eK=np.exp(-0.5j*dt*(hb*kk**2)/2.)
    n_t=int(round(T/dt)); stride=max(1,n_t//n_sample)
    ts,sg=[0.],[]
    def sigma(psi):
        rho=np.abs(psi)**2; nrm=np.sum(rho)*dx
        xm=np.sum(x*rho)*dx/nrm; x2=np.sum(x**2*rho)*dx/nrm
        dp=np.fft.ifft(1j*kk*np.fft.fft(psi))
        p2=np.sum(hb**2*np.abs(dp)**2)*dx/nrm
        pm=np.sum(hb*np.imag(np.conj(psi)*dp))*dx/nrm
        xp=np.sum(x*hb*np.imag(np.conj(psi)*dp))*dx/nrm
        S=np.array([[x2-xm**2,xp-xm*pm],[xp-xm*pm,p2-pm**2]])
        return max(np.linalg.eigvalsh(S).max(),1e-300)
    sg.append(sigma(psi))
    for i in range(n_t):
        t=i*dt
        psi=np.fft.ifft(eK*np.fft.fft(psi))
        psi=np.exp(-1j*dt*(0.5*(1+A*f(M.WP*(t+0.5*dt)))*x**2+(beta/4)*x**4)/hb)*psi
        psi=np.fft.ifft(eK*np.fft.fft(psi))
        if (i+1)%stride==0: ts.append(t+dt); sg.append(sigma(psi))
    return np.array(ts),np.array(sg)

def F_of(f,hb,beta,A,T):
    ts,sg=quantum_wf(f,hb,beta,A,T)
    ta,sa=M.period_average(ts,sg)
    smax=sa.max(); idx=np.where(sa>=0.60*smax)[0]
    ie=idx[0] if len(idx) else len(sa)-1
    if ie<6: return np.nan,np.nan
    t,y=ta[1:ie],np.log(sa[1:ie])
    c=np.polyfit(t,y,1); r=y-np.polyval(c,t)
    r2=1-np.sum(r**2)/np.sum((y-y.mean())**2)
    return 0.5*c[0]/hbar_wf(f,A,t[0],t[-1]), r2

