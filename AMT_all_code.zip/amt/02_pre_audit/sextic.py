import numpy as np
import pre_model as M
from factor_lib import WF, hbar_wf
A=0.125; BETA=1/6.

def quantum_pot(f,hb,Vfun,T=50.,dt=2e-3,L=48.,N=2048,n_sample=3000):
    x,dx,kk=M.make_grid(L,N)
    s=np.sqrt(hb/2.); psi=np.exp(-x**2/(4*s**2))+0j
    psi/=np.sqrt(np.sum(np.abs(psi)**2)*dx)
    eK=np.exp(-0.5j*dt*(hb*kk**2)/2.)
    Van=Vfun(x)
    n_t=int(round(T/dt)); stride=max(1,n_t//n_sample); ts,sg=[0.],[]
    def sigma(psi):
        rho=np.abs(psi)**2; nrm=np.sum(rho)*dx
        xm=np.sum(x*rho)*dx/nrm; x2=np.sum(x**2*rho)*dx/nrm
        dp=np.fft.ifft(1j*kk*np.fft.fft(psi))
        p2=np.sum(hb**2*np.abs(dp)**2)*dx/nrm
        pm=np.sum(hb*np.imag(np.conj(psi)*dp))*dx/nrm
        xp=np.sum(x*hb*np.imag(np.conj(psi)*dp))*dx/nrm
        S=np.array([[x2-xm**2,xp-xm*pm],[xp-xm*pm,p2-pm**2]])
        return max(np.linalg.eigvalsh(S).max(),1e-300)
    sg.append(sigma(psi))
    for i in range(n_t):
        t=i*dt
        psi=np.fft.ifft(eK*np.fft.fft(psi))
        psi=np.exp(-1j*dt*(0.5*(1+A*f(M.WP*(t+0.5*dt)))*x**2+Van)/hb)*psi
        psi=np.fft.ifft(eK*np.fft.fft(psi))
        if (i+1)%stride==0: ts.append(t+dt); sg.append(sigma(psi))
    return np.array(ts),np.array(sg)

def F_fix(f,hb,Vfun,t0=5.,t1=40.,T=50.):
    ts,sg=quantum_pot(f,hb,Vfun,T=T)
    ta,sa=M.period_average(ts,sg)
    m=(ta>=t0)&(ta<=t1); t,y=ta[m],np.log(sa[m])
    c=np.polyfit(t,y,1); r=y-np.polyval(c,t)
    return 0.5*c[0]/hbar_wf(f,A,t0,t1), 1-np.sum(r**2)/np.sum((y-y.mean())**2)

Vq=lambda x:(BETA/4)*x**4
def Vs(g): return lambda x:(g/6)*x**6
g_mean=lambda hb:3*BETA/(5*(hb/2))
g_rms =lambda hb:3*BETA/(np.sqrt(500)*(hb/2))

if __name__=="__main__":
    K={'cos':0.3886,'square':0.5020,'tri':0.3164}
    f=WF['cos']
    print(f"{'chi':>10} {'P_Kerr':>8} {'g(mean)':>8} {'P_6 mean':>9} {'g(rms)':>8} {'P_6 rms':>8}")
    for hb in [0.024,0.0625,0.125]:
        Pk=F_fix(f,hb,Vq)[0]/K['cos']
        gm=g_mean(hb); gr=g_rms(hb)
        P6m=F_fix(f,hb,Vs(gm))[0]/K['cos']
        P6r=F_fix(f,hb,Vs(gr))[0]/K['cos']
        print(f"{hb/24:>10.3e} {Pk:>8.4f} {gm:>8.3f} {P6m:>9.4f} {gr:>8.3f} {P6r:>8.4f}")
