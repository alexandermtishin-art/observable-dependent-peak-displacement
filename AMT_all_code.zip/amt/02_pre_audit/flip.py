import sys, time, numpy as np
from lattice import coeffs, barrier
from obs_energy import quantum_E, classical_E, fit_cosh
from propagate import h_bar
U=1/24.; A=0.05; T=150.; dt=4e-3; F0,F1=0.02,0.30
hb=float(sys.argv[1]); ks=[float(v) for v in sys.argv[2].split(',')]
hh=h_bar(A,F0*T,F1*T)
print(f"# hbar={hb}  chi={hb*U:.3e}  <h>={hh:.5f}  оценщик: cosh-фит по энергии")
print(f"{'k':>5} {'V_b':>6} {'N_b':>6} {'F_qm':>8} {'F_cl':>8} {'resid':>8} {'R2q':>8} {'R2c':>8}")
for k in ks:
    a,b=coeffs(k,U); Vb,xb=barrier(a,b,k)
    t0=time.time()
    tq,Eq,pq=quantum_E('lattice',k,hb,A,T=T,dt=dt,N=2048,U=U)
    tc,Ec,pc=classical_E('lattice',k,hb,A,T=T,dt=dt,n_traj=10000,U=U)
    lq,r2q=fit_cosh(tq,Eq,F0,F1); lc,r2c=fit_cosh(tc,Ec,F0,F1)
    print(f"{k:>5.2f} {Vb:>6.3f} {Vb/hb:>6.2f} {lq/hh:>8.4f} {lc/hh:>8.4f} "
          f"{(lq-lc)/hh:>+8.4f} {r2q:>8.5f} {r2c:>8.5f}  [{time.time()-t0:.0f}s]")
