"""
Трансмон в конвенции Cohen et al., PRX Quantum 4, 020312 (2023), Eq. (3):
   H~ = (n~ - n~_g)^2/2 - cos(phi) + eps_d~ cos(w_d~ t~) n~ ,  n~ = -i hbar_eff d_phi
   hbar_eff = sqrt(8 E_C/E_J),  n~_g = hbar_eff * n_g,  t~ = w_p t
Протокол: медленное нарастание eps_d~ (ring-up резонатора), старт в собственном
состоянии; ионизация = скачок средней энергии <H_0> выше энергии сепаратрисы 2.
"""
import numpy as np

def setup(EJ_EC, ng=0.25, N=256):
    hb=np.sqrt(8.0/EJ_EC)
    phi=np.linspace(-np.pi,np.pi,N,endpoint=False); dphi=phi[1]-phi[0]
    k=np.round(np.fft.fftfreq(N,d=dphi)*2*np.pi)          # целые заряды
    V=1.0-np.cos(phi)                                      # сдвиг на +1, учтён ниже
    kin=0.5*(hb*(k-ng))**2
    K=np.real(np.fft.ifft(np.diag(kin)@np.fft.fft(np.eye(N),axis=0),axis=0))
    H=K+np.diag(V); H=(H+H.T)/2
    E,U=np.linalg.eigh(H)
    return hb,phi,dphi,k,V,kin,E,U

def ramp(EJ_EC=500.,ng=0.25,wd=1.34,eps_max=1.6,T=3000.,dt=5e-3,N=256,level=0,n_sample=600):
    hb,phi,dphi,k,V,kin,E,U=setup(EJ_EC,ng,N)
    psi=U[:,level].astype(complex)/np.sqrt(dphi)
    psi/=np.sqrt(np.sum(np.abs(psi)**2)*dphi)
    eV=np.exp(-1j*dt*V/hb)
    n_t=int(round(T/dt)); stride=max(1,n_t//n_sample)
    es,Hm=[],[]
    def meanH(psi):
        f=np.fft.fft(psi); f/=np.sqrt(np.sum(np.abs(f)**2))
        return float(np.sum(kin*np.abs(f)**2)) + float(np.sum(V*np.abs(psi)**2)*dphi)
    for i in range(n_t):
        t=i*dt; ed=eps_max*(t+0.5*dt)/T
        ph=np.exp(-0.5j*dt*(kin + ed*np.cos(wd*(t+0.5*dt))*hb*(k-ng))/hb)
        psi=np.fft.ifft(ph*np.fft.fft(psi)); psi=eV*psi
        psi=np.fft.ifft(ph*np.fft.fft(psi))
        if (i+1)%stride==0:
            es.append(eps_max*(t+dt)/T); Hm.append(meanH(psi))
    return np.array(es),np.array(Hm),hb,E

if __name__=="__main__":
    print("якорь: EJ/EC=500, wd~=1.34, ng=0.25  ->  Cohen: ионизация при eps_d~ ~ 1.1 (осн.), ~0.75 (1-е возб.)")
    for lev,nm in [(0,'основное'),(1,'первое возб.')]:
        es,Hm,hb,E=ramp(level=lev)
        i=np.argmax(Hm>2.0)
        thr=es[i] if Hm.max()>2.0 else np.nan
        print(f"  {nm:14s} hbar_eff={hb:.4f} (1/hb={1/hb:.2f})  <H>_нач={Hm[0]:.4f}  "
              f"порог eps_d~={thr:.3f}  <H>_кон={Hm[-1]:.3f}")
