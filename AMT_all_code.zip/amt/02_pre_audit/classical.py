"""
Matched-width classical Liouville ensemble on the same driven potential.

Same V(x,t) = (1 + A cos w_p t) V0(x) as propagate.py.
Initial ensemble = Wigner transform of the quantum initial state:
Gaussian with  sigma_x^2 = hbar/(2 Om0),  sigma_p^2 = hbar Om0/2.

Returns the same observables (lam_FT, F, P_well, Gam_esc) so the two
branches can be compared with an identical estimator and an identical
<h> convention.
"""
import numpy as np
from lattice import coeffs, barrier

def dV0(x, kind, U=1/24.0, klat=1.0, Om0=1.0):
    if kind == "harmonic":
        return Om0**2 * x
    a, b = coeffs(klat, U, Om0)
    return a*klat*np.sin(klat*x) + 2*b*klat*np.sin(2*klat*x)

def x_barrier(kind, U=1/24.0, klat=1.0, Om0=1.0):
    if kind == "harmonic":
        return np.inf
    a, b = coeffs(klat, U, Om0)
    return barrier(a, b, klat)[1]

def run_classical(kind="lattice", U=1/24.0, klat=1.0, hbar=0.125, A=0.10,
                  T=200.0, dt=4e-3, n_traj=20000, Om0=1.0,
                  n_sample=400, seed=0):
    rng = np.random.default_rng(seed)
    sx = np.sqrt(hbar/(2*Om0))
    sp = np.sqrt(hbar*Om0/2)
    x = rng.normal(0.0, sx, n_traj)
    p = rng.normal(0.0, sp, n_traj)
    xb = x_barrier(kind, U, klat, Om0)
    w_p = 2.0*Om0

    n_t = int(round(T/dt)); stride = max(1, n_t//n_sample)
    ts, sig, pw = [0.0], [], []

    def obs(x, p):
        S = np.cov(np.vstack([x, p]))
        pwv = np.mean(np.abs(x) < xb) if np.isfinite(xb) else 1.0
        return max(np.linalg.eigvalsh(S).max(), 1e-300), pwv

    s, q = obs(x, p); sig.append(s); pw.append(q)

    for n in range(n_t):                       # velocity-Verlet
        t = n*dt
        f0 = -(1.0 + A*np.cos(w_p*t)) * dV0(x, kind, U, klat, Om0)
        p += 0.5*dt*f0
        x += dt*p
        f1 = -(1.0 + A*np.cos(w_p*(t+dt))) * dV0(x, kind, U, klat, Om0)
        p += 0.5*dt*f1
        if (n+1) % stride == 0:
            s, q = obs(x, p)
            ts.append(t+dt); sig.append(s); pw.append(q)

    return np.array(ts), np.array(sig), np.array(pw), {"x_b": xb, "n_traj": n_traj}


if __name__ == "__main__":
    from propagate import analyse
    print("=== КОНТРОЛЬ классической ветки: гармоника ===")
    for A in [0.05, 0.10]:
        ts, sig, pw, _ = run_classical(kind="harmonic", hbar=0.125, A=A,
                                       T=200 if A == 0.05 else 110, n_traj=40000)
        r = analyse(ts, sig, pw, A)
        print(f"  A={A:<5} lam={r['lam_FT']:.6f}  A/4={A/4:.6f}  "
              f"F={r['F']:.5f}  (pi/8={np.pi/8:.5f})  R2={r['R2']:.6f}")
