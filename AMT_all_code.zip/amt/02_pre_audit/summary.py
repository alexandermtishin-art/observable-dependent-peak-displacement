import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
rows=[
(1.042e-2,0.70,2.666,10.66,0.2537,0.2120,0.9307,1.07,1.27,1.0000),
(1.042e-2,1.00,2.000, 8.00,0.2484,0.2084,0.9244,1.13,1.27,1.0000),
(1.042e-2,1.60,0.940, 3.76,0.1056,0.7776,0.4140,1.28,11.44,0.9970),
(5.208e-3,0.70,2.666,21.32,0.3457,0.3244,0.9909,1.63,1.62,1.0000),
(5.208e-3,1.00,2.000,16.00,0.3446,0.3225,0.9907,1.62,1.61,1.0000),
(5.208e-3,1.60,0.940, 7.52,0.3178,0.2839,0.9821,1.03,1.50,1.0000),
(5.208e-4,0.70,2.666,213.24,0.3928,0.3923,0.9994,5.45,5.43,1.0000),
(5.208e-4,1.00,2.000,160.00,0.3928,0.3923,0.9994,5.43,5.41,1.0000),
(5.208e-4,1.60,0.940, 75.20,0.3927,0.3922,0.9994,5.01,5.00,1.0000)]
hdr="chi,k,V_b,N_b,F_qm,F_cl,resid,R2_qm,growth_qm,growth_cl,P_well"
with open('plane_results.csv','w') as f:
    f.write(hdr+"\n")
    for r in rows:
        f.write(f"{r[0]:.4e},{r[1]},{r[2]},{r[3]},{r[4]:.4f},{r[5]:.4f},{r[4]-r[5]:+.4f},{r[6]:.4f},{r[7]},{r[8]},{r[9]}\n")

a=np.array(rows)
fig,ax=plt.subplots(1,2,figsize=(10,4))
ok=a[:,6]>0.9
for k,mk in [(0.70,'o'),(1.00,'s'),(1.60,'^')]:
    m=(a[:,1]==k)&ok
    ax[0].plot(a[m,0],a[m,4],mk+'-',label=f'k={k}, V_b={a[m,2][0]:.2f}')
    ax[0].plot(a[m,0],a[m,5],mk+'--',mfc='none')
ax[0].axhline(np.pi/8,color='k',lw=.8,ls=':'); ax[0].text(6e-4,0.397,r'$\pi/8$',fontsize=9)
ax[0].set_xscale('log'); ax[0].set_xlabel(r'$\chi=\hbar_{\rm eff}|U|$'); ax[0].set_ylabel('F')
ax[0].legend(fontsize=7); ax[0].set_title('сплошная — квант, пунктир — классика')

m=ok
ax[1].loglog(a[m,0],a[m,4]-a[m,5],'ko')
x=np.logspace(-3.4,-1.9,50)
ax[1].loglog(x,4.0*x,'r--',lw=.8,label=r'$\propto\chi$')
ax[1].loglog(x,[0.08]*50,'b:',lw=1,label='плато 0.08 (PRE)')
ax[1].set_xlabel(r'$\chi$'); ax[1].set_ylabel(r'$F_{qm}-F_{cl}$'); ax[1].legend(fontsize=8)
ax[1].set_title('остаток закрывается, а не выходит на плато')
plt.tight_layout(); plt.savefig('plane.png',dpi=140)
print(open('plane_results.csv').read())
