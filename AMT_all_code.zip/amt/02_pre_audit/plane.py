import sys, time, numpy as np
from lattice import coeffs, barrier
from propagate import run, fit_rate, h_bar
from classical import run_classical

U=1/24.; A=0.05; T=200.; dt=4e-3
W0,W1=0.02,0.15          # раннее окно фита (одинаковое для обеих веток)
hb=float(sys.argv[1]); N=int(sys.argv[2]); ntraj=int(sys.argv[3])
hbar_h=h_bar(A, W0*T, W1*T, convention='mean')

print(f"# hbar_eff={hb}  chi={hb*U:.3e}  <h>={hbar_h:.5f}  N={N} ntraj={ntraj}")
print(f"{'k':>5} {'V_b':>6} {'N_b':>7} {'F_qm':>8} {'F_cl':>8} {'resid':>8} "
      f"{'R2q':>7} {'R2c':>7} {'gr_q':>6} {'gr_c':>6} {'Pwell':>7} {'Gesc':>9}")
for k in [0.7,1.0,1.6]:
    a,b=coeffs(k,U); Vb,xb=barrier(a,b,k)
    t0=time.time()
    tq,sq,pq,_=run(kind='lattice',U=U,klat=k,hbar=hb,A=A,T=T,dt=dt,N=N,n_sample=400,init='vacuum')
    tc,sc,pc,_=run_classical(kind='lattice',U=U,klat=k,hbar=hb,A=A,T=T,dt=dt,n_traj=ntraj)
    lq=0.5*fit_rate(tq,sq,W0,W1)[0]; r2q=fit_rate(tq,sq,W0,W1)[2]
    lc=0.5*fit_rate(tc,sc,W0,W1)[0]; r2c=fit_rate(tc,sc,W0,W1)[2]
    Fq,Fc=lq/hbar_h, lc/hbar_h
    grq=np.sqrt(sq[-1]/sq[0]); grc=np.sqrt(sc[-1]/sc[0])
    Ge=0.0
    if pq[-1]<0.999:
        Ge=-fit_rate(tq,np.maximum(pq,1e-12),W0,0.5)[0]
    print(f"{k:>5.2f} {Vb:>6.3f} {Vb/hb:>7.2f} {Fq:>8.4f} {Fc:>8.4f} {Fq-Fc:>+8.4f} "
          f"{r2q:>7.4f} {r2c:>7.4f} {grq:>6.2f} {grc:>6.2f} {pq[-1]:>7.4f} {Ge:>9.2e}"
          f"   [{time.time()-t0:.0f}s]")
