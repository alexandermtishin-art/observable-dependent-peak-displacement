"""
Floquet analysis of the driven transmon in the convention of
Cohen, Petrescu, Shillito & Blais, PRX Quantum 4, 020312 (2023), Eq. (3):

    H~(t~) = (n~ - n~_g)^2/2 - cos(phi) + eps_d~ cos(w_d~ t~) n~
    n~ = -i hbar_eff d_phi ,  hbar_eff = sqrt(8 E_C/E_J) ,  n~_g = hbar_eff n_g

Builds the one-period propagator U_F, diagonalises it, and computes the mean
energy per cycle  <<H>> = (1/T) int_0^T <phi_k(t)|H(t)|phi_k(t)> dt   [their Eq. 4].

Ionisation threshold = drive amplitude at which the tracked Floquet mode is
absorbed into the chaotic layer at <<H>>/E_J = 2 (separatrix energy).
"""
import numpy as np


def grid(EJ_EC, ng=0.25, N=256):
    hb = np.sqrt(8.0/EJ_EC)
    phi = np.linspace(-np.pi, np.pi, N, endpoint=False)
    dphi = phi[1] - phi[0]
    k = np.round(np.fft.fftfreq(N, d=dphi)*2*np.pi)      # integer charges
    nt = hb*(k - ng)                                      # n~ - n~_g in Fourier
    kin = 0.5*nt**2
    V = -np.cos(phi)                                      # their -cos(phi)
    return hb, phi, dphi, k, nt, kin, V


def static_states(EJ_EC, ng=0.25, N=256):
    hb, phi, dphi, k, nt, kin, V = grid(EJ_EC, ng, N)
    K = np.real(np.fft.ifft(np.diag(kin)@np.fft.fft(np.eye(N), axis=0), axis=0))
    H = K + np.diag(V); H = (H + H.T)/2
    return np.linalg.eigh(H)


def floquet(EJ_EC=500., ng=0.25, wd=1.34, ed=0.5, N=256, n_step=600, n_obs=40):
    """Return (quasienergies, modes, mean energy per cycle) for drive ed."""
    hb, phi, dphi, k, nt, kin, V = grid(EJ_EC, ng, N)
    Td = 2*np.pi/wd
    dt = Td/n_step
    eV = np.exp(-1j*dt*V/hb)[:, None]

    def step(M, t):
        ph = np.exp(-0.5j*dt*(kin + ed*np.cos(wd*t)*nt)/hb)[:, None]
        M = np.fft.ifft(ph*np.fft.fft(M, axis=0), axis=0)
        M = eV*M
        return np.fft.ifft(ph*np.fft.fft(M, axis=0), axis=0)

    U = np.eye(N, dtype=complex)
    for i in range(n_step):
        U = step(U, (i+0.5)*dt)
    lam, W = np.linalg.eig(U)
    quasi = -hb*np.angle(lam)/Td

    # mean energy per cycle for each Floquet mode
    M = W/np.sqrt(np.sum(np.abs(W)**2, axis=0))[None, :]
    obs_every = max(1, n_step//n_obs)
    acc = np.zeros(N); cnt = 0
    for i in range(n_step):
        if i % obs_every == 0:
            F = np.fft.fft(M, axis=0)
            F = F/np.sqrt(np.sum(np.abs(F)**2, axis=0))[None, :]
            t = i*dt
            e = (np.sum(kin[:, None]*np.abs(F)**2, axis=0)
                 + ed*np.cos(wd*t)*np.sum(nt[:, None]*np.abs(F)**2, axis=0)
                 + np.sum(V[:, None]*np.abs(M)**2, axis=0))
            acc += np.real(e); cnt += 1
        M = step(M, (i+0.5)*dt)
    return quasi, W, acc/cnt


def track(EJ_EC=500., ng=0.25, wd=1.34, level=0, ed_max=1.6, n_ed=64, N=256,
          n_step=600, verbose=True):
    """Track a Floquet mode from zero drive; report where <<H>> crosses 2."""
    E0, U0 = static_states(EJ_EC, ng, N)
    ref = U0[:, level].astype(complex)
    eds = np.linspace(ed_max/n_ed, ed_max, n_ed)
    out = []
    thr = np.nan
    for ed in eds:
        quasi, W, mh = floquet(EJ_EC, ng, wd, ed, N, n_step)
        Wn = W/np.linalg.norm(W, axis=0)[None, :]
        ov = np.abs(ref.conj()@Wn)
        j = int(np.argmax(ov))
        # mean energy is measured from the well bottom (-1 -> 0), so add 1
        out.append((ed, mh[j] + 1.0, ov[j]))
        if np.isnan(thr) and mh[j] + 1.0 > 2.0:
            thr = ed
        ref = Wn[:, j]
    if verbose:
        for ed, e, o in out:
            print(f"    eps_d~={ed:5.3f}  <<H>>/EJ={e:7.3f}  overlap={o:.3f}")
    return np.array([o[0] for o in out]), np.array([o[1] for o in out]), thr


if __name__ == "__main__":
    print("ЯКОРЬ 1: EJ/EC=500 (1/hbar_eff=7.91), wd~=1.34, ng=0.25")
    print("  Cohen et al.: ионизация при eps_d~ ~ 1.1 (осн.), ~ 0.75 (1-е возб.)")
    for lev, nm in [(0, 'основное'), (1, 'первое возб.')]:
        eds, mh, thr = track(level=lev, verbose=False)
        print(f"  {nm:14s}: порог eps_d~ = {thr:.3f}   <<H>> при eps=1.6: {mh[-1]:.2f}")
