import numpy as np, sys, time
import pre_model as M
from factor_lib import quantum_wf, WF, hbar_wf
A=0.125
def F_fixed(f,hb,beta,T,t0,t1):
    ts,sg=quantum_wf(f,hb,beta,A,T)
    ta,sa=M.period_average(ts,sg)
    m=(ta>=t0)&(ta<=t1)
    t,y=ta[m],np.log(sa[m])
    c=np.polyfit(t,y,1); r=y-np.polyval(c,t)
    r2=1-np.sum(r**2)/np.sum((y-y.mean())**2)
    return 0.5*c[0]/hbar_wf(f,A,t0,t1), r2, sa[m][-1]/sa[0]
