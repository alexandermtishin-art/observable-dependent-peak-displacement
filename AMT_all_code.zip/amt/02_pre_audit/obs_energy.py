"""
Energy-absorption observable.

E(t) = <p^2/2 + V0(x)>  with the STATIC V0 (undriven), so that E measures
energy pumped into the oscillator rather than instantaneous drive work.

For parametric amplification  E ~ e^{2 lam t},  so
    lam_E = (1/2) d ln E / dt
must coincide with the covariance-based lam in the clean regime.

Harmonic control: lam_E = A/4,  F = lam_E/<h> = pi/8.
"""
import numpy as np
from lattice import coeffs, V0, barrier
from propagate import make_grid
from classical import dV0

U_DEF = 1/24.


def quantum_E(kind, k, hbar, A, T=200., dt=4e-3, N=2048, U=U_DEF,
              L=None, in_well=True, n_sample=400):
    if kind == "harmonic":
        L = 40.0 if L is None else L
        x, dx, kk = make_grid(L, N)
        Vst = 0.5*x**2
        xb = np.inf
    else:
        a, b = coeffs(k, U)
        _, xb = barrier(a, b, k)
        L = 6*(2*np.pi/k) if L is None else L
        x, dx, kk = make_grid(L, N)
        Vst = V0(x, a, b, k)
    s = np.sqrt(hbar/2.)
    psi = np.exp(-x**2/(4*s**2)) + 0j
    psi /= np.sqrt(np.sum(np.abs(psi)**2)*dx)
    eK = np.exp(-0.5j*dt*(hbar*kk**2)/2.)
    mask = (np.abs(x) < xb) if (in_well and np.isfinite(xb)) else np.ones_like(x, bool)

    def energy(psi):
        dpsi = np.fft.ifft(1j*kk*np.fft.fft(psi))
        kin = 0.5*hbar**2*np.abs(dpsi)**2
        pot = Vst*np.abs(psi)**2
        n = np.sum(np.abs(psi[mask])**2)*dx
        return (np.sum(kin[mask]) + np.sum(pot[mask]))*dx/max(n, 1e-300), n

    n_t = int(round(T/dt)); stride = max(1, n_t//n_sample)
    ts, Es, pw = [0.], [], []
    e0, p0 = energy(psi); Es.append(e0); pw.append(p0)
    for i in range(n_t):
        t = i*dt
        psi = np.fft.ifft(eK*np.fft.fft(psi))
        psi = np.exp(-1j*dt*(1.+A*np.cos(2*(t+0.5*dt)))*Vst/hbar)*psi
        psi = np.fft.ifft(eK*np.fft.fft(psi))
        if (i+1) % stride == 0:
            e, p = energy(psi); ts.append(t+dt); Es.append(e); pw.append(p)
    return np.array(ts), np.array(Es), np.array(pw)


def classical_E(kind, k, hbar, A, T=200., dt=4e-3, n_traj=15000, U=U_DEF,
                in_well=True, seed=1, n_sample=400):
    if kind == "harmonic":
        xb = np.inf
        dv = lambda z: z
        pot = lambda z: 0.5*z**2
    else:
        a, b = coeffs(k, U)
        _, xb = barrier(a, b, k)
        dv = lambda z: dV0(z, 'lattice', U, k)
        pot = lambda z: V0(z, a, b, k)
    rng = np.random.default_rng(seed)
    s = np.sqrt(hbar/2.)
    x = rng.normal(0, s, n_traj); p = rng.normal(0, s, n_traj)

    def energy(x, p):
        m = (np.abs(x) < xb) if (in_well and np.isfinite(xb)) else np.ones_like(x, bool)
        if m.sum() == 0:
            return 0.0, 0.0
        return np.mean(0.5*p[m]**2 + pot(x[m])), m.mean()

    n_t = int(round(T/dt)); stride = max(1, n_t//n_sample)
    ts, Es, pw = [0.], [], []
    e0, p0 = energy(x, p); Es.append(e0); pw.append(p0)
    for i in range(n_t):
        t = i*dt
        p += 0.5*dt*(-(1.+A*np.cos(2*t))*dv(x))
        x += dt*p
        p += 0.5*dt*(-(1.+A*np.cos(2*(t+dt)))*dv(x))
        if (i+1) % stride == 0:
            e, q = energy(x, p); ts.append(t+dt); Es.append(e); pw.append(q)
    return np.array(ts), np.array(Es), np.array(pw)


if __name__ == "__main__":
    from propagate import fit_rate, h_bar
    print("=== ВАЛИДАЦИЯ наблюдаемой по энергии: гармоника ===")
    print("ожидается lam_E = A/4 и F = pi/8 = 0.392699\n")
    for A in [0.05, 0.10]:
        T = 200. if A == 0.05 else 110.
        hh = h_bar(A, 0.02*T, 0.15*T)
        tq, Eq, _ = quantum_E("harmonic", 1.0, 0.125, A, T=T, N=1024, L=50.)
        tc, Ec, _ = classical_E("harmonic", 1.0, 0.125, A, T=T, n_traj=30000)
        lq, _, r2q = fit_rate(tq, Eq, 0.02, 0.15)
        lc, _, r2c = fit_rate(tc, Ec, 0.02, 0.15)
        print(f"  A={A:<5} lam_E(qm)={0.5*lq:.6f}  lam_E(cl)={0.5*lc:.6f}  "
              f"A/4={A/4:.6f}   F_qm={0.5*lq/hh:.5f}  F_cl={0.5*lc/hh:.5f}  "
              f"R2={r2q:.5f}/{r2c:.5f}")


def fit_cosh(ts, E, f0=0.02, f1=0.30):
    """Model fit  E(t) = E0 cosh(2 lam t)  -> lam.  Valid in the transient."""
    from scipy.optimize import curve_fit
    T = ts[-1]
    m = (ts >= f0*T) & (ts <= f1*T)
    t, y = ts[m], E[m]
    E0 = E[0]
    f = lambda tt, lam, e0: e0*np.cosh(2*lam*tt)
    try:
        popt, _ = curve_fit(f, t, y, p0=[0.01, E0], maxfev=20000)
    except Exception:
        return np.nan, np.nan
    lam = abs(popt[0])
    resid = y - f(t, *popt)
    r2 = 1 - np.sum(resid**2)/np.sum((y - y.mean())**2)
    return lam, r2
