"""
Decisive run: hold N_b fixed, vary hbar_eff.

  A (ladder discreteness)      -> divergence depends on N_b  -> flat along the line
  C (unresolved stochastic layer) -> divergence depends on hbar_eff -> grows along it

In-well covariance: all moments restricted to |x| < x_b, so that in-well
amplification is measured separately from escape.
"""
import sys, time
import numpy as np
from lattice import coeffs, barrier, V0
from propagate import make_grid, potential, fit_rate, h_bar
from classical import dV0

U = 1/24.; A = 0.05; T = 200.; dt = 4e-3
W0, W1 = 0.02, 0.15


def cov_from_moments(n, x1, x2, p1, p2, xp):
    if n <= 0:
        return 1e-300
    xm, pm = x1/n, p1/n
    S = np.array([[x2/n - xm**2, xp/n - xm*pm],
                  [xp/n - xm*pm, p2/n - pm**2]])
    return max(np.linalg.eigvalsh(S).max(), 1e-300)


def quantum(k, hbar, N, T=T, dt=dt):
    a, b = coeffs(k, U); Vb, xb = barrier(a, b, k)
    L = 6*(2*np.pi/k)
    x, dx, kk = make_grid(L, N)
    Vst = V0(x, a, b, k)
    s = np.sqrt(hbar/2.)
    psi = np.exp(-x**2/(4*s**2)) + 0j
    psi /= np.sqrt(np.sum(np.abs(psi)**2)*dx)
    eK = np.exp(-0.5j*dt*(hbar*kk**2)/2.)
    mask = np.abs(x) < xb
    n_t = int(round(T/dt)); stride = max(1, n_t//400)
    ts, sg, pw = [0.], [], []

    def obs(psi):
        rho = np.abs(psi)**2
        dpsi = np.fft.ifft(1j*kk*np.fft.fft(psi))
        jx = hbar*np.imag(np.conj(psi)*dpsi)          # local p-density
        # p^2 density via |grad psi|^2 * hbar^2
        p2d = hbar**2*np.abs(dpsi)**2
        n = np.sum(rho[mask])*dx
        sig = cov_from_moments(n,
                               np.sum(x[mask]*rho[mask])*dx,
                               np.sum(x[mask]**2*rho[mask])*dx,
                               np.sum(jx[mask])*dx,
                               np.sum(p2d[mask])*dx,
                               np.sum(x[mask]*jx[mask])*dx)
        return sig, n/(np.sum(rho)*dx)

    s0, p0 = obs(psi); sg.append(s0); pw.append(p0)
    for i in range(n_t):
        t = i*dt
        psi = np.fft.ifft(eK*np.fft.fft(psi))
        psi = np.exp(-1j*dt*(1.+A*np.cos(2*(t+0.5*dt)))*Vst/hbar)*psi
        psi = np.fft.ifft(eK*np.fft.fft(psi))
        if (i+1) % stride == 0:
            sv, pv = obs(psi); ts.append(t+dt); sg.append(sv); pw.append(pv)
    return np.array(ts), np.array(sg), np.array(pw), Vb, xb


def classical(k, hbar, n_traj=15000, T=T, dt=dt, seed=1):
    a, b = coeffs(k, U); Vb, xb = barrier(a, b, k)
    rng = np.random.default_rng(seed)
    s = np.sqrt(hbar/2.)
    x = rng.normal(0, s, n_traj); p = rng.normal(0, s, n_traj)
    n_t = int(round(T/dt)); stride = max(1, n_t//400)
    ts, sg, pw = [0.], [], []

    def obs(x, p):
        m = np.abs(x) < xb
        n = m.sum()
        sig = cov_from_moments(n, x[m].sum(), (x[m]**2).sum(),
                               p[m].sum(), (p[m]**2).sum(), (x[m]*p[m]).sum())
        return sig, n/len(x)

    s0, p0 = obs(x, p); sg.append(s0); pw.append(p0)
    for i in range(n_t):
        t = i*dt
        f = -(1.+A*np.cos(2*t))*dV0(x, 'lattice', U, k)
        p += 0.5*dt*f; x += dt*p
        f = -(1.+A*np.cos(2*(t+dt)))*dV0(x, 'lattice', U, k)
        p += 0.5*dt*f
        if (i+1) % stride == 0:
            sv, pv = obs(x, p); ts.append(t+dt); sg.append(sv); pw.append(pv)
    return np.array(ts), np.array(sg), np.array(pw)


if __name__ == "__main__":
    Nb_target = float(sys.argv[1])
    ks = [float(v) for v in sys.argv[2].split(',')]
    Ngrid = int(sys.argv[3])
    hh = h_bar(A, W0*T, W1*T, convention='mean')
    print(f"# N_b = {Nb_target} фиксировано;  <h> = {hh:.5f}")
    print(f"{'k':>5} {'V_b':>6} {'hbar':>7} {'chi':>9} {'F_in_qm':>8} {'F_in_cl':>8} "
          f"{'resid':>8} {'Pw_qm':>7} {'Pw_cl':>7} {'R2q':>6} {'R2c':>6}")
    for k in ks:
        a, b = coeffs(k, U); Vb, xb = barrier(a, b, k)
        hbar = Vb/Nb_target
        t0 = time.time()
        tq, sq, pq, _, _ = quantum(k, hbar, Ngrid)
        tc, sc, pc = classical(k, hbar)
        lq, _, r2q = fit_rate(tq, sq, W0, W1)
        lc, _, r2c = fit_rate(tc, sc, W0, W1)
        print(f"{k:>5.2f} {Vb:>6.3f} {hbar:>7.4f} {hbar*U:>9.2e} "
              f"{0.5*lq/hh:>8.4f} {0.5*lc/hh:>8.4f} {0.5*(lq-lc)/hh:>+8.4f} "
              f"{pq[-1]:>7.4f} {pc[-1]:>7.4f} {r2q:>6.3f} {r2c:>6.3f}  [{time.time()-t0:.0f}s]")
