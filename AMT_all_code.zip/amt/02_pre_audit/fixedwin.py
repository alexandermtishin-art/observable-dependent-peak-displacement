import numpy as np, sys, time
import pre_model as M
from factor_lib import quantum_wf, WF, hbar_wf
A=0.125
def F_fixed(f,hb,beta,T,t0,t1):
    ts,sg=quantum_wf(f,hb,beta,A,T)
    ta,sa=M.period_average(ts,sg)
    m=(ta>=t0)&(ta<=t1)
    t,y=ta[m],np.log(sa[m])
    c=np.polyfit(t,y,1); r=y-np.polyval(c,t)
    r2=1-np.sum(r**2)/np.sum((y-y.mean())**2)
    return 0.5*c[0]/hbar_wf(f,A,t0,t1), r2, sa[m][-1]/sa[0]
t0,t1=float(sys.argv[2]),float(sys.argv[3])
print(f"общее окно t=[{t0},{t1}]")
print(f"{'hbar':>8} {'chi':>10} {'K':>8} {'F_kerr':>8} {'P':>8} {'R2г':>7} {'R2к':>7} {'рост_г':>7} {'рост_к':>7}")
for hb in [float(v) for v in sys.argv[1].split(',')]:
    K,r2h,gh=F_fixed(WF['cos'],hb,0.0,120.,t0,t1)
    Fk,r2k,gk=F_fixed(WF['cos'],hb,1/6.,120.,t0,t1)
    print(f"{hb:>8.4f} {hb/24:>10.3e} {K:>8.4f} {Fk:>8.4f} {Fk/K:>8.4f} {r2h:>7.4f} {r2k:>7.4f} {gh:>7.2f} {gk:>7.2f}")
