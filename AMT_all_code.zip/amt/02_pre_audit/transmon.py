"""
Driven transmon in the semiclassical picture (resonator = classical drive).

    H = 4E_C n^2 - E_J cos(phi) + eps cos(w_d t) phi

Rescaled by E_J and by the plasma frequency w_p = sqrt(8 E_J E_C):

    H~ = -(hbar~^2/2) d_phi^2 + (1 - cos phi) + eps~ cos(w~_d t) phi
    hbar~ = sqrt(8 E_C / E_J)        <-- their h_eff
    Omega_0 = 1,  |U| = 1/24,  V_b = 2,  N_b = 2/hbar~ = sqrt(E_J/2E_C)

Observable: P_well(t) = population with |phi| < pi  (inside the cosine well).
Ionization = loss of P_well.
"""
import numpy as np
from propagate import make_grid


def hbar_eff(EJ_EC):
    return np.sqrt(8.0/EJ_EC)


def n_bound(EJ_EC):
    return 2.0/hbar_eff(EJ_EC)


def run_transmon(EJ_EC=50., eps=0.02, wd=1.0, T=400., dt=2e-3,
                 n_periods=8, N=4096, n_sample=400, absorb=True):
    hb = hbar_eff(EJ_EC)
    L = n_periods*2*np.pi
    x, dx, kk = make_grid(L, N)
    V0 = 1.0 - np.cos(x)
    s = np.sqrt(hb/2.)
    psi = np.exp(-x**2/(4*s**2)) + 0j
    psi /= np.sqrt(np.sum(np.abs(psi)**2)*dx)
    eK = np.exp(-0.5j*dt*(hb*kk**2)/2.)

    # optional absorbing layer at the box edges (CAP), off by default in checks
    if absorb:
        w = 0.12*L
        edge = np.clip((np.abs(x) - (L/2 - w))/w, 0, None)
        cap = np.exp(-dt*3.0*edge**2)
    else:
        cap = 1.0

    well = np.abs(x) < np.pi
    n_t = int(round(T/dt)); stride = max(1, n_t//n_sample)
    ts, pw, en = [0.], [], []

    def obs(psi):
        rho = np.abs(psi)**2
        nrm = np.sum(rho)*dx
        dpsi = np.fft.ifft(1j*kk*np.fft.fft(psi))
        E = (np.sum(0.5*hb**2*np.abs(dpsi)**2) + np.sum(V0*rho))*dx/max(nrm, 1e-300)
        return np.sum(rho[well])*dx/max(nrm, 1e-300), E

    p0, e0 = obs(psi); pw.append(p0); en.append(e0)
    for i in range(n_t):
        t = i*dt
        psi = np.fft.ifft(eK*np.fft.fft(psi))
        Vt = V0 + eps*np.cos(wd*(t+0.5*dt))*x
        psi = np.exp(-1j*dt*Vt/hb)*psi
        psi = np.fft.ifft(eK*np.fft.fft(psi))
        psi = cap*psi
        if (i+1) % stride == 0:
            p, e = obs(psi); ts.append(t+dt); pw.append(p); en.append(e)
    return np.array(ts), np.array(pw), np.array(en), hb


def classical_transmon(EJ_EC=50., eps=0.02, wd=1.0, T=400., dt=2e-3,
                       n_traj=20000, seed=2, n_sample=400):
    hb = hbar_eff(EJ_EC)
    rng = np.random.default_rng(seed)
    s = np.sqrt(hb/2.)
    x = rng.normal(0, s, n_traj); p = rng.normal(0, s, n_traj)
    n_t = int(round(T/dt)); stride = max(1, n_t//n_sample)
    ts, pw = [0.], [np.mean(np.abs(x) < np.pi)]
    for i in range(n_t):
        t = i*dt
        f = -(np.sin(x) + eps*np.cos(wd*t))
        p += 0.5*dt*f
        x += dt*p
        f = -(np.sin(x) + eps*np.cos(wd*(t+dt)))
        p += 0.5*dt*f
        if (i+1) % stride == 0:
            ts.append(t+dt); pw.append(np.mean(np.abs(x) < np.pi))
    return np.array(ts), np.array(pw)


if __name__ == "__main__":
    print("отображение параметров:")
    print(f"{'EJ/EC':>7} {'hbar_eff':>9} {'N_b':>7}")
    for r in [30., 50., 100., 200.]:
        print(f"{r:>7.0f} {hbar_eff(r):>9.4f} {n_bound(r):>7.2f}")
