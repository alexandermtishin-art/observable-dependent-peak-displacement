import numpy as np, sys, time
import pre_model as M
from factor_lib import F_of, WF, hbar_wf
A=0.125
print(f"{'hbar':>8} {'chi':>10} {'K':>8} {'F_kerr':>8} {'P':>8} {'R2':>7} {'t,s':>6}")
for hb in [float(v) for v in sys.argv[1].split(',')]:
    T=float(sys.argv[2]); t0=time.time()
    K,_=F_of(WF['cos'],hb,0.0,A,T)
    Fk,r2=F_of(WF['cos'],hb,1/6.,A,T)
    print(f"{hb:>8.4f} {hb/24:>10.3e} {K:>8.4f} {Fk:>8.4f} {Fk/K:>8.4f} {r2:>7.4f} {time.time()-t0:>6.0f}")
