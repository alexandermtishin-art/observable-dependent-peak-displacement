"""
Stress test of Theorem 1: same evolution, different admissible observation maps.

Produces the numbers in Table 2 of "Observable-Dependent Peak Displacement in
Projected Quantum Dynamics", rows 1-3.

The Hamiltonian, initial state, control protocol and integration are fixed; the
integration is performed ONCE.  The three diagnostics differ only in which
Hermitian observable is used to build the scalar signal from the evolved state:

    sigma_max  : largest eigenvalue of the 2x2 covariance matrix
    Var_x      : position variance alone
    Var_p      : momentum variance alone

Requires SM_grid_engine.py (release version) on the path.
"""
import numpy as np
from SM_grid_engine import (make_grid, ground_state, potential,
                            secular_rate, h_window)

A, HBAR, BETA = 0.20, 0.25, 1.0/6.0
WP, L, M, DT, TWIN = 2.0, 24.0, 4096, 1.5e-3, 30.0

def moments(psi, x, dx, k, hbar):
    rho = np.abs(psi)**2; nrm = np.sum(rho)*dx
    ex  = np.sum(x*rho)*dx/nrm
    ex2 = np.sum(x*x*rho)*dx/nrm
    ph  = np.fft.fft(psi); Np = np.sum(np.abs(ph)**2)
    ep  = hbar    * np.sum(np.conj(ph)*k*ph).real / Np
    ep2 = hbar**2 * np.sum(np.conj(ph)*k*k*ph).real / Np
    pp  = np.fft.ifft(hbar*k*np.fft.fft(psi))
    exp_xp = np.sum(np.conj(psi)*x*pp).real*dx/nrm
    Vx, Vp = ex2-ex*ex, ep2-ep*ep
    C = exp_xp - ex*ep
    smax = 0.5*(Vx+Vp) + np.sqrt(max(0.25*(Vx-Vp)**2 + C*C, 0.0))
    return smax, Vx, Vp

def run():
    x, dx, k = make_grid(L, M)
    psi = ground_state(x, dx, k, potential('kerr', x, 1.0, BETA), HBAR)
    eK  = np.exp(-1j*HBAR*0.5*k*k*DT)
    n   = int(TWIN/DT)
    ts, S = [], [[], [], []]
    for i in range(n):
        t  = i*DT
        O2 = 1.0 + A*np.cos(WP*t)
        hV = np.exp(-1j*potential('kerr', x, O2, BETA)/HBAR*DT/2)
        psi = hV*psi
        psi = np.fft.ifft(eK*np.fft.fft(psi))
        psi = hV*psi
        if i % 8 == 0:
            m = moments(psi, x, dx, k, HBAR)
            ts.append(t)
            for j in range(3): S[j].append(m[j])
    ts = np.array(ts)
    names = ['covariance top eigenvalue', 'position variance Var_x',
             'momentum variance Var_p']
    print(f"{'observable':>30} {'F':>9} {'R2':>8} {'window':>16}")
    for nm, arr in zip(names, S):
        lam, r2, sp, w = secular_rate(ts, np.array(arr))
        if np.isnan(lam):
            print(f'{nm:>30} {"no accepted rate":>9}'); continue
        print(f'{nm:>30} {lam/h_window(A, w[0], w[1]):>9.4f} '
              f'{r2:>8.4f} [{w[0]:5.1f},{w[1]:5.1f}]')

if __name__ == '__main__':
    run()
