import json, os, sys, time
import numpy as np
from SM_grid_engine import run_gain, classical_ensemble, secular_rate, h_window, eta_char, classical_tangent
DB='data.json'
def load():
    return json.load(open(DB)) if os.path.exists(DB) else {}
def save(d): json.dump(d,open(DB,'w'),indent=1)
def key(*a): return '|'.join(str(x) for x in a)

def q(kind,A,hb,L=24.,M=4096,Twin=30.,dt=1.5e-3):
    d=load(); k=key('q',kind,A,hb,L,M,Twin)
    if k in d: return d[k]
    ts,sig,_=run_gain(kind,A,hbar=hb,Twin=Twin,dt=dt,M=M,L=L)
    l,r2,sp,w=secular_rate(ts,sig)
    v=[np.nan,np.nan,np.nan] if np.isnan(l) else [l/h_window(A,w[0],w[1]),r2,sp]
    d[k]=v; save(d); return v

def e(kind,A,hb,N=4000,Twin=30.):
    d=load(); k=key('e',kind,A,hb,N,Twin)
    if k in d: return d[k]
    ts,sig,_=classical_ensemble(kind,A,hbar=hb,Ntraj=N,Twin=Twin)
    l,r2,sp,w=secular_rate(ts,sig)
    v=[np.nan,np.nan,np.nan] if np.isnan(l) else [l/h_window(A,w[0],w[1]),r2,sp]
    d[k]=v; save(d); return v
