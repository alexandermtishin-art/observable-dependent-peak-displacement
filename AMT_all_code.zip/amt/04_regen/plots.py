import json, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from SM_grid_engine import eta_char, classical_tangent, h_window
d=json.load(open('data.json'))
PI8=np.pi/8
def g(k): 
    v=d.get(k); return (np.nan,np.nan,np.nan) if v is None else tuple(v)
def acc(r2,sp): return (not np.isnan(r2)) and r2>=0.98 and sp<=0.10
plt.rcParams.update({'font.size':10,'axes.linewidth':0.9})
As=[0.10,0.14,0.20,0.28,0.40,0.55,0.70,0.85]; xis=np.array([eta_char(A)*24 for A in As])

# ---------------- Fig 2
sty={'harm':('#888','o','harmonic (Mathieu, linear)'),
     'kerr':('#1f3b6e','s','Kerr (confining)'),
     'hard':('#2a8f4e','D','hard $x^6$ (confining)'),
     'transmon':('#a11','^','transmon-type (escape)')}
fig,ax=plt.subplots(figsize=(6.8,4.8))
ax.axhline(PI8,ls=':',color='0.45',lw=1.2)
ax.text(1.6,PI8+0.014,r'harmonic reference $\pi/8=0.3927$',fontsize=8.5,color='0.4')
for p in ['harm','kerr','hard','transmon']:
    L,M=(48.0,8192) if p=='transmon' else (24.0,4096)
    F=[];R2=[];SP=[]
    for A in As:
        a,b,c=g(f'q|{p}|{A}|1.0|{L}|{M}|30.0'); F.append(a);R2.append(b);SP.append(c)
    F=np.array(F);R2=np.array(R2);SP=np.array(SP)
    col,mk,lab=sty[p]; m=~np.isnan(F)
    if m.any():
        ax.plot(xis[m],F[m],mk+'-',color=col,ms=6,lw=1.5,label=lab)
        bad=np.array([not acc(r,s) for r,s in zip(R2,SP)])&m
        if bad.any(): ax.plot(xis[bad],F[bad],mk,color=col,ms=10,mfc='none',mew=1.8)
    nn=np.isnan(F)
    if nn.any(): ax.plot(xis[nn],np.full(nn.sum(),-0.04),'x',color=col,ms=7,mew=1.6)
ax.plot([],[],'kx',ms=7,label='no accepted rate (window criterion)')
ax.set_xscale('log'); ax.set_ylim(-0.08,0.50)
ax.set_xlabel(r'$\xi=\eta/|U|$   ($|U|=1/24$,  $\hbar_{\rm eff}=1$)')
ax.set_ylabel(r'$F=\lambda_{\rm param}/\langle h\rangle$')
ax.set_title('Parametric gain at $\\hbar_{\\rm eff}=1$: platforms do not collapse',fontsize=10.5)
ax.grid(alpha=0.25,which='both'); ax.legend(fontsize=8.2,loc='upper right',framealpha=.93)
fig.tight_layout(); fig.savefig('fig2_new.png',dpi=170); plt.close(fig)

# ---------------- Fig 3
hbs=np.array([1.0,0.5,0.25,0.125,0.06])
fig,ax=plt.subplots(figsize=(6.8,4.8))
ax.axhline(PI8,ls='--',color='0.4',lw=1.2)
ax.text(0.5,PI8+0.008,r'harmonic reference $\pi/8=0.3927$',fontsize=8.5,color='0.4',ha='center')
for p,col,mk,lab,LM in [('kerr','#1f3b6e','s','Kerr (confining)',(24.0,4096)),
                        ('transmon','#a11','^','transmon-type (escape)',(48.0,8192))]:
    F=[];R2=[];SP=[]
    for hb in hbs:
        a,b,c=g(f'q|{p}|0.2|{hb}|{LM[0]}|{LM[1]}|30.0'); F.append(a);R2.append(b);SP.append(c)
    F=np.array(F);R2=np.array(R2);SP=np.array(SP); m=~np.isnan(F)
    ax.plot(hbs[m],F[m],mk+'-',color=col,ms=7,lw=1.6,label=lab)
    bad=np.array([not acc(r,s) for r,s in zip(R2,SP)])&m
    if bad.any(): ax.plot(hbs[bad],F[bad],mk,color=col,ms=11,mfc='none',mew=1.8)
ax.set_xscale('log'); ax.invert_xaxis(); ax.set_ylim(0.15,0.44)
ax.set_xlabel(r'$\hbar_{\rm eff}$   (larger = more quantum $\rightarrow$ smaller = more classical)')
ax.set_ylabel(r'$F$ at fixed $\xi\simeq3$')
ax.set_title('Finite-width recovery toward the harmonic reference',fontsize=10.5)
ax.grid(alpha=.25,which='both'); ax.legend(loc='lower left',fontsize=9,framealpha=.93)
fig.tight_layout(); fig.savefig('fig3_new.png',dpi=170); plt.close(fig)

# ---------------- Fig 4
Fq=[];Fc=[];Rq=[];Rc=[];Sq=[];Sc=[]
for hb in hbs:
    a,b,c=g(f'q|kerr|0.2|{hb}|24.0|4096|30.0'); Fq.append(a);Rq.append(b);Sq.append(c)
    a,b,c=g(f'e|kerr|0.2|{hb}|4000|30.0');      Fc.append(a);Rc.append(b);Sc.append(c)
Fq=np.array(Fq);Fc=np.array(Fc); m=~np.isnan(Fq)
fig,(ax,ax2)=plt.subplots(1,2,figsize=(10.6,4.4),gridspec_kw={'width_ratios':[1.35,1]})
ax.axhline(PI8,ls='--',color='0.4',lw=1.1)
ax.text(0.075,PI8+0.003,r'harmonic reference $\pi/8$',fontsize=8.5,color='0.4',ha='center')
ax.plot(hbs[m],Fc[m],'o-',color='#2a7',ms=8,lw=1.7,label='classical ensemble (matched width)')
ax.plot(hbs[m],Fq[m],'s--',color='#1f3b6e',ms=6,lw=1.7,label='quantum (grid)')
for arr,R2,SP,col,mk in [(Fq,Rq,Sq,'#1f3b6e','s'),(Fc,Rc,Sc,'#2a7','o')]:
    bad=np.array([not acc(r,s) for r,s in zip(R2,SP)])&m
    if bad.any(): ax.plot(hbs[bad],np.array(arr)[bad],mk,color=col,ms=12,mfc='none',mew=1.8)
ax.set_xscale('log'); ax.invert_xaxis(); ax.set_ylim(0.30,0.41)
ax.set_xlabel(r'$\hbar_{\rm eff}$  (larger = broader initial width)')
ax.set_ylabel(r'$F$ at fixed $\xi\simeq3$')
ax.set_title('(a) quantum and classical-ensemble gain',fontsize=10.5)
ax.grid(alpha=.25,which='both'); ax.legend(loc='lower left',fontsize=8.6,framealpha=.93)

ax2.axhspan(-0.002,0.002,color='0.88',zorder=0,label='numerical uncertainty of the rate')
ax2.axhline(0,color='0.5',lw=1.0)
ax2.plot(hbs[m],(Fq-Fc)[m],'k^-',ms=8,lw=1.7)
ax2.set_xscale('log'); ax2.invert_xaxis(); ax2.set_ylim(-0.008,0.008)
ax2.set_xlabel(r'$\hbar_{\rm eff}$')
ax2.set_ylabel(r'$\Delta F=F_{\rm qm}-F_{\rm cl}$')
ax2.set_title('(b) quantum$-$classical difference',fontsize=10.5)
ax2.grid(alpha=.25,which='both'); ax2.legend(loc='upper left',fontsize=8.4,framealpha=.93)
fig.tight_layout(); fig.savefig('fig4_new.png',dpi=170); plt.close(fig)
print('готово')
for nm,F in [('kerr q',Fq),('kerr cl',Fc)]: print(nm,np.round(F,4))
print('остаток',np.round(Fq-Fc,4))
