"""Robustness figure: the common position of the maxima moves strongly with
hbar_eff and A (Kerr shift of the resonance), while the splitting between
observation maps stays put."""
import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

db = json.load(open('robustness.json'))
OBS = ['Var_x', 'sigma_max', 'Var_p']
LBL = {'sigma_max': r'$\sigma_{\max}$', 'Var_x': r'${\rm Var}_x$', 'Var_p': r'${\rm Var}_p$'}
COL = {'sigma_max': '#222222', 'Var_x': '#1f77b4', 'Var_p': '#d62728'}

def series(fixed_key, fixed_val, var_key):
    rows = [r for r in db.values() if abs(r[fixed_key] - fixed_val) < 1e-9]
    rows.sort(key=lambda r: r[var_key])
    return np.array([r[var_key] for r in rows]), \
           {o: np.array([r['peaks'][o] for r in rows]) for o in OBS}

fig, ax = plt.subplots(1, 3, figsize=(12.5, 3.8))

xa, Pa = series('hbar', 0.25, 'A')
for o in OBS:
    ax[0].plot(xa, Pa[o], 'o-', color=COL[o], ms=5, label=LBL[o])
ax[0].set_xlabel(r'pump amplitude $A$   ($\hbar_{\rm eff}=0.25$)')
ax[0].set_ylabel(r'$\delta^{(A)}_{\max}$'); ax[0].legend(frameon=False, fontsize=8)
ax[0].set_title('(a)  Pump-amplitude robustness', fontsize=10, loc='left')

xh, Ph = series('A', 0.20, 'hbar')
for o in OBS:
    ax[1].plot(xh, Ph[o], 'o-', color=COL[o], ms=5, label=LBL[o])
ax[1].set_xlabel(r'$\hbar_{\rm eff}$   ($A=0.20$)')
ax[1].set_ylabel(r'$\delta^{(A)}_{\max}$'); ax[1].legend(frameon=False, fontsize=8)
ax[1].set_title('(b)  Quantum-width robustness', fontsize=10, loc='left')

lbls, s1, s2 = [], [], []
for tag, r in sorted(db.items(), key=lambda kv: (kv[1]['A'], kv[1]['hbar'])):
    lbls.append(f"{r['A']:g}/{r['hbar']:g}")
    s1.append(r['peaks']['sigma_max'] - r['peaks']['Var_x'])
    s2.append(r['peaks']['Var_p'] - r['peaks']['sigma_max'])
xs = np.arange(len(lbls))
ax[2].plot(xs, s1, 's-', color='#1f77b4', ms=5, label=r'$\sigma_{\max}-{\rm Var}_x$')
ax[2].plot(xs, s2, 's-', color='#d62728', ms=5, label=r'${\rm Var}_p-\sigma_{\max}$')
ax[2].axhline(0, color='0.6', lw=0.8)
ax[2].set_xticks(xs); ax[2].set_xticklabels(lbls, rotation=45, fontsize=8)
ax[2].set_xlabel(r'$A$ / $\hbar_{\rm eff}$'); ax[2].set_ylabel('splitting')
ax[2].set_ylim(0, 0.030); ax[2].legend(frameon=False, fontsize=8)
ax[2].set_title('(c)  Common displacement versus splitting', fontsize=10, loc='left')

plt.tight_layout(); plt.savefig('fig_robustness.png', dpi=200)
print('common position range:', round(min(min(Ph[o]) for o in OBS), 4), '-',
      round(max(max(Ph[o]) for o in OBS), 4))
print('sigma-x  range:', round(min(s1), 5), '-', round(max(s1), 5))
print('p-sigma  range:', round(min(s2), 5), '-', round(max(s2), 5))
print('peak/hbar ratios (A=0.20):',
      [round(v, 3) for v in (Ph['sigma_max'] / xh)])
