"""Timestep convergence control: repeats the fine scan on a reduced delta grid
with dt halved (3e-3 -> 1.5e-3).  Peak positions must not move appreciably."""
import sys, numpy as np
sys.path.insert(0, '../01_release')
import delta_scan as D
from SM_grid_engine import make_grid, ground_state, potential

D.DT, D.REC = 1.5e-3, 16          # halved step, same recording cadence in time
ds = np.linspace(0.005, 0.165, 17)
x, dx, k = make_grid(D.L, D.M)
psi0 = ground_state(x, dx, k, potential(D.KIND, x, 1.0, D.BETA), D.HBAR)
F = {o: [] for o in D.OBS}
for d in ds:
    ts, S = D.trajectory(d, psi0, x, dx, k)
    for o in D.OBS: F[o].append(D.rate(ts, S[o], 2.0 + d, D.T0, D.T1)[0])
    print('.', end='', flush=True)
print()
def peak(d, f, half=0.03):
    f = np.array(f); i = int(np.nanargmax(f)); m = np.abs(d - d[i]) <= half
    return -np.polyfit(d[m], f[m], 2)[1] / (2 * np.polyfit(d[m], f[m], 2)[0])
for o in D.OBS:
    print(f'{o:>10}: {peak(ds, F[o]):+.5f}')
