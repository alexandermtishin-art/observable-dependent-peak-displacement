"""
Frequency-scan test of Theorem 1: observable-induced displacement of the
finite-time amplification maximum in detuning space.

Protocol
--------
Control parameter:  delta = omega_p - 2*Omega0   (Omega0 = 1)
For each delta the Schroedinger equation is integrated ONCE.  From that single
trajectory three admissible scalar signals are read off:

    sigma_max : largest eigenvalue of the 2x2 covariance matrix
    Var_x     : position variance
    Var_p     : momentum variance

All three are then processed by an IDENTICAL estimator: the same period-averaged
smoothing, the same fit window, the same argmax interpolation.  The window is
pre-registered ONCE for the whole scan (not per observable, not per delta), so
that the only thing that differs between the three extracted maxima is the
observation map.

Engine: 01_release/SM_grid_engine.py (audited release version).
"""
import numpy as np, json, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '01_release'))
from SM_grid_engine import make_grid, ground_state, potential

# ---------------------------------------------------------------- parameters
A, HBAR, BETA = 0.20, 0.25, 1.0 / 6.0
# Production settings actually used for the reported numbers.  M and DT were
# reduced from the 05_stress values (4096, 1.5e-3) only after a convergence
# check: at delta = 0 the three rates agree to 4e-6 absolute, and dtcheck.py
# confirms the extracted peak positions move by <= 4e-4 when dt is halved.
L, M, DT, TWIN, REC = 24.0, 2048, 3e-3, 30.0, 8
O0 = 1.0
KIND = 'kerr'

# pre-registered common fit window (fixed for every delta and every observable)
T0, T1 = 3.0, 14.0
SAT_FRAC = 0.6          # window must stay below this fraction of the signal max

OBS = ['sigma_max', 'Var_x', 'Var_p']


# ---------------------------------------------------------------- evolution
def moments(psi, x, dx, k, hbar):
    rho = np.abs(psi) ** 2
    nrm = np.sum(rho) * dx
    ex = np.sum(x * rho) * dx / nrm
    ex2 = np.sum(x * x * rho) * dx / nrm
    ph = np.fft.fft(psi)
    Np = np.sum(np.abs(ph) ** 2)
    ep = hbar * np.sum(np.conj(ph) * k * ph).real / Np
    ep2 = hbar ** 2 * np.sum(np.conj(ph) * k * k * ph).real / Np
    pp = np.fft.ifft(hbar * k * np.fft.fft(psi))
    exp_xp = np.sum(np.conj(psi) * x * pp).real * dx / nrm
    Vx, Vp = ex2 - ex * ex, ep2 - ep * ep
    C = exp_xp - ex * ep
    smax = 0.5 * (Vx + Vp) + np.sqrt(max(0.25 * (Vx - Vp) ** 2 + C * C, 0.0))
    return smax, Vx, Vp


def trajectory(delta, psi0, x, dx, k):
    """One integration; returns (t, {observable: signal})."""
    wp = 2.0 * O0 + delta
    psi = psi0.copy()
    eK = np.exp(-1j * HBAR * 0.5 * k * k * DT)
    n = int(TWIN / DT)
    ts, S = [], [[], [], []]
    for i in range(n):
        t = i * DT
        O2 = O0 ** 2 * (1 + A * np.cos(wp * t))
        hV = np.exp(-1j * potential(KIND, x, O2, BETA) / HBAR * DT / 2)
        psi = hV * psi
        psi = np.fft.ifft(eK * np.fft.fft(psi))
        psi = hV * psi
        if i % REC == 0:
            m = moments(psi, x, dx, k, HBAR)
            ts.append(t)
            for j in range(3):
                S[j].append(m[j])
    return np.array(ts), {OBS[j]: np.array(S[j]) for j in range(3)}


# ---------------------------------------------------------------- estimator
def rate(ts, sig, wp, t0, t1):
    """Identical estimator for every observable: period-average, log-linear fit
    on the fixed window [t0, t1].  Returns (Lambda, R2, sat_fraction_reached)."""
    dts = ts[1] - ts[0]
    period = 2 * np.pi / wp
    win = max(3, int(period / dts))
    sm = np.convolve(sig, np.ones(win) / win, mode='valid')
    tsm = ts[win - 1:]
    m = (tsm >= t0) & (tsm <= t1)
    if m.sum() < 12:
        return np.nan, np.nan, np.nan
    t, y = tsm[m], np.log(np.clip(sm[m], 1e-300, None))
    Amat = np.vstack([t, np.ones(len(t))]).T
    sl, ic = np.linalg.lstsq(Amat, y, rcond=None)[0]
    yhat = sl * t + ic
    r2 = 1 - np.sum((y - yhat) ** 2) / np.sum((y - y.mean()) ** 2)
    satf = sm[m].max() / sm.max()
    return sl / 2, r2, satf


def argmax_parabolic(d, f):
    """Sub-grid argmax by 3-point parabolic interpolation about the peak node."""
    ok = np.isfinite(f)
    d, f = d[ok], f[ok]
    i = int(np.argmax(f))
    if i == 0 or i == len(d) - 1:
        return d[i], False
    x0, x1, x2 = d[i - 1], d[i], d[i + 1]
    y0, y1, y2 = f[i - 1], f[i], f[i + 1]
    den = (y0 - 2 * y1 + y2)
    if den == 0:
        return x1, False
    return x1 - 0.5 * (x2 - x1) * (y2 - y0) / den, True


# ---------------------------------------------------------------- driver
def scan(deltas, psi0, x, dx, k):
    out = {o: [] for o in OBS}
    r2s = {o: [] for o in OBS}
    sats = {o: [] for o in OBS}
    for n, d in enumerate(deltas):
        ts, S = trajectory(d, psi0, x, dx, k)
        wp = 2.0 * O0 + d
        for o in OBS:
            lam, r2, satf = rate(ts, S[o], wp, T0, T1)
            out[o].append(lam); r2s[o].append(r2); sats[o].append(satf)
        print(f'  delta={d:+.4f}  ' +
              '  '.join(f'{o}={out[o][-1]:.5f}' for o in OBS), flush=True)
    return ({o: np.array(v) for o, v in out.items()},
            {o: np.array(v) for o, v in r2s.items()},
            {o: np.array(v) for o, v in sats.items()})


if __name__ == '__main__':
    x, dx, k = make_grid(L, M)
    psi0 = ground_state(x, dx, k, potential(KIND, x, O0 ** 2, BETA), HBAR)

    print('--- coarse scan ---')
    dc = np.linspace(-0.30, 0.30, 25)
    Fc, R2c, SATc = scan(dc, psi0, x, dx, k)

    peaks_c = {o: argmax_parabolic(dc, Fc[o])[0] for o in OBS}
    print('\ncoarse peaks:', {o: round(v, 5) for o, v in peaks_c.items()})

    lo = min(peaks_c.values()) - 0.05
    hi = max(peaks_c.values()) + 0.05
    print(f'\n--- fine scan on [{lo:.4f}, {hi:.4f}] ---')
    df = np.linspace(lo, hi, 41)
    Ff, R2f, SATf = scan(df, psi0, x, dx, k)

    res = {'coarse': {'delta': dc.tolist(),
                      **{o: Fc[o].tolist() for o in OBS},
                      **{o + '_r2': R2c[o].tolist() for o in OBS},
                      **{o + '_sat': SATc[o].tolist() for o in OBS}},
           'fine': {'delta': df.tolist(),
                    **{o: Ff[o].tolist() for o in OBS},
                    **{o + '_r2': R2f[o].tolist() for o in OBS},
                    **{o + '_sat': SATf[o].tolist() for o in OBS}},
           'params': dict(A=A, hbar=HBAR, beta=BETA, L=L, M=M, dt=DT,
                          Twin=TWIN, rec=REC, t0=T0, t1=T1, kind=KIND)}
    with open(os.path.join(os.path.dirname(__file__), 'scan.json'), 'w') as f:
        json.dump(res, f)

    print('\n=== fine-scan peaks (fixed common window) ===')
    for o in OBS:
        p, interp = argmax_parabolic(df, Ff[o])
        print(f'{o:>10}: delta_max = {p:+.5f}   R2(min)={np.nanmin(R2f[o]):.4f} '
              f' sat_max={np.nanmax(SATf[o]):.3f}  interp={interp}')
