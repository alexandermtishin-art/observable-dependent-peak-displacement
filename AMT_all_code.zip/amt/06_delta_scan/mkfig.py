"""Figure: (a) the three normalised amplification curves with their maxima;
(b) the extracted maxima across every estimator variant passing the
pre-registered acceptance (R2 >= 0.98)."""
import sys, itertools, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0, '../01_release')
import delta_scan as D
from estimator import rate_pa

z = np.load('signals.npz'); ds = z['delta']; t = z['t']; OBS = D.OBS
LBL = {'sigma_max': r'$\sigma_{\max}$', 'Var_x': r'${\rm Var}_x$', 'Var_p': r'${\rm Var}_p$'}
COL = {'sigma_max': '#222222', 'Var_x': '#1f77b4', 'Var_p': '#d62728'}
NPASS_REF, T0_REF, T1_REF = 2, 3.0, 13.0

def sweep(t0, t1, npass):
    F, ok = {}, True
    for o in OBS:
        q = [rate_pa(t, z[o][i], 2.0 + d, t0, t1, npass=npass) for i, d in enumerate(ds)]
        if np.nanmin([w[1] for w in q]) < 0.98:
            ok = False
        F[o] = np.array([w[0] for w in q])
    return F, ok

def peak(d, f, half=0.03):
    i = int(np.nanargmax(f)); m = np.abs(d - d[i]) <= half
    c = np.polyfit(d[m], f[m], 2); return -c[1] / (2 * c[0])

fig, ax = plt.subplots(1, 2, figsize=(10.5, 4.0))

F, _ = sweep(T0_REF, T1_REF, NPASS_REF)
for o in OBS:
    y = F[o] / F[o].max(); p = peak(ds, F[o])
    ax[0].plot(ds, y, '-', color=COL[o], lw=1.8, label=LBL[o])
    ax[0].axvline(p, color=COL[o], ls='--', lw=1.0, alpha=.8)
    ax[0].plot([p], [1.0], 'o', color=COL[o], ms=5)
ax[0].axvline(0.0, color='0.5', lw=1.0)
ax[0].set_xlabel(r'detuning  $\delta=\omega_p-2\Omega_0$')
ax[0].set_ylabel(r'$\Lambda^{(A)}_\delta\,/\,\max_\delta\Lambda^{(A)}_\delta$')
ax[0].set_ylim(0.90, 1.008)
ax[0].legend(frameon=False, loc='lower center')
ax[0].set_title('(a)  One dynamics, three observation maps', fontsize=10, loc='left')

acc = []
for t0, t1, npass in itertools.product((2.5, 3.0, 3.5, 4.0),
                                       (11., 12., 13., 14., 15., 16.), (1, 2, 3, 4)):
    G, ok = sweep(t0, t1, npass)
    if ok: acc.append((f'{t0:g}-{t1:g}/{npass}', [peak(ds, G[o]) for o in OBS]))
xs = np.arange(len(acc))
for j, o in enumerate(OBS):
    ax[1].plot(xs, [p[j] for _, p in acc], 'o-', color=COL[o], ms=4, lw=1.0, label=LBL[o])
ax[1].set_xticks(xs[::3]); ax[1].set_xticklabels([a for a, _ in acc][::3], rotation=70, fontsize=7)
ax[1].set_xlabel(r'accepted estimator variant  $[t_0,t_1]$ / passes')
ax[1].set_ylabel(r'$\delta^{(A)}_{\max}$')
ax[1].set_title(f'(b)  Ordering persists across all {len(acc)} accepted\n'
                f'      estimator variants', fontsize=10, loc='left')
ax[1].legend(frameon=False, fontsize=8)
plt.tight_layout(); plt.savefig('fig_observable_scan.png', dpi=200)
print('reference peaks:', {o: round(peak(ds, F[o]), 5) for o in OBS})
print('accepted variants:', len(acc))
