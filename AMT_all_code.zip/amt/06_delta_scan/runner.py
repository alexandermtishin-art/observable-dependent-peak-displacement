"""Stage driver: runs the coarse or the fine detuning scan and caches results.

    python runner.py coarse     -> coarse.json   (delta in [-0.30, 0.30], 25 pts)
    python runner.py fine       -> fine.json     (deltas from fine_deltas.json)
"""
import sys, json, numpy as np
sys.path.insert(0, '../01_release')
import delta_scan as D
from SM_grid_engine import make_grid, ground_state, potential

stage = sys.argv[1]
x, dx, k = make_grid(D.L, D.M)
psi0 = ground_state(x, dx, k, potential(D.KIND, x, 1.0, D.BETA), D.HBAR)

if stage == 'coarse':
    ds = np.linspace(-0.30, 0.30, 25)
else:
    ds = np.array(json.load(open('fine_deltas.json')))

F, R2, SAT = D.scan(ds, psi0, x, dx, k)
json.dump({'delta': ds.tolist(),
           **{o: F[o].tolist() for o in D.OBS},
           **{o + '_r2': R2[o].tolist() for o in D.OBS},
           **{o + '_sat': SAT[o].tolist() for o in D.OBS}},
          open(f'{stage}.json', 'w'))
print('\npeaks:', {o: round(D.argmax_parabolic(ds, F[o])[0], 5) for o in D.OBS})
