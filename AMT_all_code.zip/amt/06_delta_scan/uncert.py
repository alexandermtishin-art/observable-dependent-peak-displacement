import sys, numpy as np
sys.path.insert(0,'../01_release')
import delta_scan as D
z = np.load('signals.npz'); ds = z['delta']; t = z['t']; OBS = D.OBS

def rates(t0, t1):
    out = {}
    for o in OBS:
        v = []
        for i, d in enumerate(ds):
            v.append(D.rate(t, z[o][i], 2.0 + d, t0, t1)[0])
        out[o] = np.array(v)
    return out

def peak(d, f, half=None):
    """Quadratic fit to points within `half` of the max node (None -> 3-point)."""
    i = int(np.nanargmax(f))
    if half is None:
        m = slice(max(i-1,0), i+2)
    else:
        m = np.abs(d - d[i]) <= half
    c = np.polyfit(d[m], f[m], 2)
    return -c[1]/(2*c[0])

print('=== window sensitivity (common window, all three observables) ===')
print(f"{'t0':>5}{'t1':>6}   " + ''.join(f'{o:>12}' for o in OBS) + '   spread')
rows = []
for t0 in (2.5, 3.0, 3.5, 4.0):
    for t1 in (12.0, 13.0, 14.0, 15.0, 16.0):
        F = rates(t0, t1)
        p = [peak(ds, F[o], half=0.03) for o in OBS]
        rows.append(p)
        print(f'{t0:>5.1f}{t1:>6.1f}   ' + ''.join(f'{v:>12.5f}' for v in p)
              + f'   {max(p)-min(p):.5f}')
rows = np.array(rows)
print('\nmean over 20 windows:', np.round(rows.mean(0), 5))
print('std  over 20 windows:', np.round(rows.std(0), 5))

print('\n=== interpolation / fit-width sensitivity (window 3.0-14.0) ===')
F = rates(3.0, 14.0)
for half in (None, 0.012, 0.02, 0.03, 0.04, 0.06):
    p = [peak(ds, F[o], half=half) for o in OBS]
    lab = '3-point' if half is None else f'+-{half}'
    print(f'{lab:>9}: ' + ''.join(f'{v:>12.5f}' for v in p))

print('\n=== grid-decimation bootstrap (window 3.0-14.0, half=0.03) ===')
rng = np.random.default_rng(0); B = []
for _ in range(400):
    off = rng.integers(0, 2); idx = np.arange(off, len(ds), 2)
    B.append([peak(ds[idx], F[o][idx], half=0.03) for o in OBS])
B = np.array(B)
for j, o in enumerate(OBS):
    print(f'{o:>10}: {B[:,j].mean():+.5f} +- {B[:,j].std():.5f}')

print('\n=== saturation check on window 3.0-14.0 ===')
for o in OBS:
    s = [D.rate(t, z[o][i], 2.0+d, 3.0, 14.0)[2] for i, d in enumerate(ds)]
    r = [D.rate(t, z[o][i], 2.0+d, 3.0, 14.0)[1] for i, d in enumerate(ds)]
    print(f'{o:>10}: max sat-fraction {np.nanmax(s):.3f}   min R2 {np.nanmin(r):.4f}')
