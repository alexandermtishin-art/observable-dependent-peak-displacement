"""
Robustness of the observable-induced splitting across (A, hbar_eff).
===================================================================
The frequency scan is repeated at four additional points in parameter space
around the reference (A = 0.20, hbar_eff = 0.25): two further pump amplitudes
and two further effective Planck constants.  The purpose is to show that the
splitting

    delta_max^(Var_x)  <  delta_max^(sigma_max)  <  delta_max^(Var_p)

is not an accident of one point in parameter space.

Procedure, per parameter set:
  * one integration per detuning; the three observables are read off the SAME
    trajectory;
  * the period-aware estimator (2 passes) with a SINGLE common fit window for
    all three observables;
  * t1 is re-registered per parameter set as the largest value on a fixed grid
    for which all three observables satisfy R2 >= 0.98.
    This is necessary because the growth rate scales roughly as A/4, so a
    window that is safely pre-saturation at A = 0.14 is not at A = 0.26.  The
    window remains common to the three observables, which is what the test
    requires; only its extent is adapted to the dynamics.

Note on the saturation criterion.  W3 compares the in-window maximum to the
maximum over the WHOLE recorded trajectory.  That is a meaningful measure of
proximity to saturation only if the trajectory actually reaches saturation
within Twin.  Since the growth rate scales roughly as A/4 and the time needed
to reach the nonlinear ceiling also grows as hbar_eff decreases (the initial
variance is smaller, so more e-foldings are required), Twin must be extended at
low A and low hbar_eff.  Otherwise the ratio degenerates into "fraction of the
recorded range" and rejects perfectly admissible windows: at A = 0.14 with
Twin = 30 the signal is still growing at the end of the record, and W3 reports
0.65 even for a window ending at t = 9.  Twin is therefore passed explicitly,
and `saturated` below reports whether the record really did flatten.
"""
import sys, json, os, numpy as np
sys.path.insert(0, '../01_release')
import delta_scan as D
from SM_grid_engine import make_grid, ground_state, potential
from estimator import rate_pa, period_average

NPASS, T0 = 2, 3.0
T1_GRID = [13.0]   # fixed common window for every parameter set, for comparability
R2MIN = 0.98


def peak(d, f, half=None):
    f = np.asarray(f)
    i = int(np.nanargmax(f))
    h = half if half is not None else 3.5 * (d[1] - d[0])
    m = np.abs(d - d[i]) <= h
    if m.sum() < 3:
        return np.nan
    c = np.polyfit(d[m], f[m], 2)
    return -c[1] / (2 * c[0])


def saturated(T, sig, wp, frac=0.35):
    """True if the local log-slope at the end of the record has fallen below
    `frac` of its early value, i.e. the trajectory really reached its ceiling.

    The period-aware average must be applied first: the raw Var_x and Var_p
    signals oscillate strongly within each drive period, so a slope taken over a
    sub-interval of the raw signal reflects the oscillation phase, not the
    trend, and can even come out negative.""" \
    ""
    T, sm = period_average(T, sig, wp, npass=2)
    y = np.log(np.clip(sm, 1e-300, None))
    n = len(y)
    early = np.polyfit(T[n//6:n//3], y[n//6:n//3], 1)[0]
    late = np.polyfit(T[-n//8:], y[-n//8:], 1)[0]
    return bool(late < frac * early)


def run_point(A, hbar, deltas, Twin=None):
    """Integrate once per detuning; return {observable: signal array} and t."""
    D.A, D.HBAR = A, hbar
    if Twin is not None:
        D.TWIN = Twin
    x, dx, k = make_grid(D.L, D.M)
    psi0 = ground_state(x, dx, k, potential(D.KIND, x, 1.0, D.BETA), hbar)
    sig = {o: [] for o in D.OBS}
    T = None
    for d in deltas:
        ts, S = D.trajectory(d, psi0, x, dx, k)
        T = ts
        for o in D.OBS:
            sig[o].append(S[o])
    return T, {o: np.array(v) for o, v in sig.items()}


def analyse(T, sig, deltas):
    """Pick the largest admissible common window, then extract the three peaks."""
    for t1 in T1_GRID:
        F, ok = {}, True
        for o in D.OBS:
            q = [rate_pa(T, sig[o][i], 2.0 + d, T0, t1, npass=NPASS)
                 for i, d in enumerate(deltas)]
            if np.nanmin([w[1] for w in q]) < R2MIN:
                ok = False
                break
            F[o] = np.array([w[0] for w in q])
        if ok:
            p = {o: peak(deltas, F[o]) for o in D.OBS}
            r2 = {o: float(np.nanmin([rate_pa(T, sig[o][i], 2.0 + d, T0, t1,
                                              npass=NPASS)[1]
                                      for i, d in enumerate(deltas)]))
                  for o in D.OBS}
            return t1, p, F, r2
    return None, None, None, None


if __name__ == '__main__':
    A = float(sys.argv[1]); hbar = float(sys.argv[2])
    lo, hi, n = float(sys.argv[3]), float(sys.argv[4]), int(sys.argv[5])
    Twin = float(sys.argv[6]) if len(sys.argv) > 6 else 30.0
    deltas = np.linspace(lo, hi, n)
    T, sig = run_point(A, hbar, deltas, Twin=Twin)
    mid = len(deltas) // 2
    sat_ok = all(saturated(T, sig[o][mid], 2.0 + deltas[mid]) for o in D.OBS)
    t1, p, F, r2 = analyse(T, sig, deltas)
    tag = f'A{A:g}_h{hbar:g}'
    if p is None:
        print(f'{tag}: no admissible window on the grid')
        sys.exit(1)
    edge = any(abs(p[o] - lo) < 1e-9 or abs(p[o] - hi) < 1e-9 or
               not (lo < p[o] < hi) for o in D.OBS)
    print(f'{tag}: Twin={Twin:g}  record reached saturation: {sat_ok}')
    print(f'{tag}: window [{T0}, {t1}]  ' +
          '  '.join(f'{o}={p[o]:+.5f}' for o in D.OBS))
    print('    minR2: ' + '  '.join(f'{o}={r2[o]:.5f}' for o in D.OBS))
    print(f'    sigma-x={p["sigma_max"]-p["Var_x"]:+.5f}  '
          f'p-sigma={p["Var_p"]-p["sigma_max"]:+.5f}  '
          f'ordered={p["Var_x"] < p["sigma_max"] < p["Var_p"]}'
          f'{"   EDGE WARNING" if edge else ""}')
    rec = {'A': A, 'hbar': hbar, 't1': t1, 'Twin': Twin, 'saturated': sat_ok, 'delta': deltas.tolist(),
           'peaks': {o: float(p[o]) for o in D.OBS},
           'minR2': r2, **{o: F[o].tolist() for o in D.OBS}}
    db = {}
    if os.path.exists('robustness.json'):
        db = json.load(open('robustness.json'))
    db[tag] = rec
    json.dump(db, open('robustness.json', 'w'))
