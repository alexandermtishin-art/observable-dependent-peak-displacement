"""Stores the raw three-observable signals on the fine delta grid, so that
window/estimator variation costs no further integration."""
import sys, numpy as np
sys.path.insert(0, '../01_release')
import delta_scan as D
from SM_grid_engine import make_grid, ground_state, potential

ds = np.linspace(0.005, 0.165, 41)
x, dx, k = make_grid(D.L, D.M)
psi0 = ground_state(x, dx, k, potential(D.KIND, x, 1.0, D.BETA), D.HBAR)
sig = {o: [] for o in D.OBS}; T = None
for d in ds:
    ts, S = D.trajectory(d, psi0, x, dx, k); T = ts
    for o in D.OBS: sig[o].append(S[o])
    print('.', end='', flush=True)
np.savez_compressed('signals.npz', delta=ds, t=T,
                    **{o: np.array(sig[o]) for o in D.OBS})
print(' done')
