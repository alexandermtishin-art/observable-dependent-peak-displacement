"""Envelope of the extracted maxima over ALL estimator variants that pass the
pre-registered acceptance (R2 >= 0.98 on every delta; see the note in estimator.py).

Two estimator systematics are scanned jointly:
  * the common fit window [t0, t1];
  * the number of period-averaging passes npass.
Both act identically on all three observables, so neither can create a
splitting between them; they can only shift the common position.  The question
is whether the ordering and the separation survive the whole envelope.
"""
import sys, itertools, numpy as np
import delta_scan as D
from estimator import rate_pa

z = np.load('signals.npz'); ds = z['delta']; t = z['t']; OBS = D.OBS
R2MIN = 0.98

def peak(d, f, half=0.03):
    i = int(np.nanargmax(f)); m = np.abs(d - d[i]) <= half
    c = np.polyfit(d[m], f[m], 2); return -c[1] / (2 * c[0])

acc, rej = [], 0
for t0, t1, npass in itertools.product((2.5, 3.0, 3.5, 4.0),
                                       (11., 12., 13., 14., 15., 16.),
                                       (1, 2, 3, 4)):
    P, ok = [], True
    for o in OBS:
        q = [rate_pa(t, z[o][i], 2.0 + d, t0, t1, npass=npass)
             for i, d in enumerate(ds)]
        if np.nanmin([w[1] for w in q]) < R2MIN:
            ok = False; break
        P.append(peak(ds, np.array([w[0] for w in q])))
    if ok: acc.append((t0, t1, npass, P))
    else:  rej += 1

print(f'estimator variants scanned: {len(acc)+rej}   accepted: {len(acc)}   rejected: {rej}')
A = np.array([p for *_, p in acc])
print('\nover accepted variants:')
for j, o in enumerate(OBS):
    print(f'  {o:>10}  mean {A[:,j].mean():+.5f}   min {A[:,j].min():+.5f}   max {A[:,j].max():+.5f}')
sep_sx = A[:, 0] - A[:, 1]      # sigma_max - Var_x
sep_ps = A[:, 2] - A[:, 0]      # Var_p   - sigma_max
sep_px = A[:, 2] - A[:, 1]      # Var_p   - Var_x
for nm, s in (('sigma-x', sep_sx), ('p-sigma', sep_ps), ('p-x', sep_px)):
    print(f'  separation {nm:>8}: mean {s.mean():+.5f}   min {s.min():+.5f}   max {s.max():+.5f}')
ordered = np.all((A[:, 1] < A[:, 0]) & (A[:, 0] < A[:, 2]))
print(f'\nordering Var_x < sigma_max < Var_p holds in every accepted variant: {ordered}')
print(f'smallest separation anywhere in the envelope: {min(sep_sx.min(), sep_ps.min()):.5f}')
print('\naccepted variants (t0, t1, npass):')
for t0, t1, np_, P in acc:
    print(f'  {t0:>4} {t1:>5} {np_:>2}   ' + '  '.join(f'{v:+.5f}' for v in P))
