"""Figure 1: (a) three readouts on one evolution; (b) estimator envelope;
(c) continuous displacement along a linear Hermitian observable family."""
import sys, itertools, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import delta_scan as D
from estimator import rate_pa

z = np.load('signals.npz'); ds = z['delta']; t = z['t']; OBS = D.OBS
zm = np.load('moments.npz')
LBL = {'sigma_max': r'$\sigma_{\max}$', 'Var_x': r'$\langle x^2\rangle$', 'Var_p': r'$\langle p^2\rangle$'}
COL = {'sigma_max': '#222222', 'Var_x': '#1f77b4', 'Var_p': '#d62728'}
T0, T1, NP = 3.0, 13.0, 2

def peak(d, f, half=0.03):
    i = int(np.nanargmax(f)); m = np.abs(d - d[i]) <= half
    c = np.polyfit(d[m], f[m], 2); return -c[1] / (2 * c[0])

def sweep(t0, t1, npass):
    F, ok = {}, True
    for o in OBS:
        q = [rate_pa(t, z[o][i], 2.0 + d, t0, t1, npass=npass) for i, d in enumerate(ds)]
        if np.nanmin([w[1] for w in q]) < 0.98: ok = False
        F[o] = np.array([w[0] for w in q])
    return F, ok

def lin(alpha, t0=T0, t1=T1, npass=NP):
    lam = [rate_pa(t, (1 - alpha) * zm['x2'][i] + alpha * zm['p2'][i], 2.0 + d, t0, t1, npass=npass)[0]
           for i, d in enumerate(ds)]
    return np.array(lam)

fig, ax = plt.subplots(1, 3, figsize=(14.5, 4.0))

F, _ = sweep(T0, T1, NP)
for o in OBS:
    y = F[o] / F[o].max(); p = peak(ds, F[o])
    ls = '-' if o != 'sigma_max' else '--'
    ax[0].plot(ds, y, ls, color=COL[o], lw=1.8, label=LBL[o])
    ax[0].axvline(p, color=COL[o], ls=':', lw=1.0, alpha=.8)
    ax[0].plot([p], [1.0], 'o', color=COL[o], ms=5)
ax[0].axvline(0.0, color='0.5', lw=1.0)
ax[0].set_xlabel(r'detuning  $\delta=\omega_{\rm p}-2\Omega_0$')
ax[0].set_ylabel(r'$\Lambda^{(A)}_\delta\,/\,\max_\delta\Lambda^{(A)}_\delta$')
ax[0].set_ylim(0.90, 1.008); ax[0].legend(frameon=False, loc='lower center')
ax[0].set_title('(a)  One dynamics, three readouts', fontsize=10, loc='left')

acc = []
for t0, t1, npass in itertools.product((2.5, 3.0, 3.5, 4.0), (11., 12., 13., 14., 15., 16.), (1, 2, 3, 4)):
    G, ok = sweep(t0, t1, npass)
    if ok: acc.append((f'{t0:g}-{t1:g}/{npass}', [peak(ds, G[o]) for o in OBS]))
xs = np.arange(len(acc))
for j, o in enumerate(OBS):
    ax[1].plot(xs, [p[j] for _, p in acc], 'o-', color=COL[o], ms=4, lw=1.0, label=LBL[o])
ax[1].set_xticks(xs[::4]); ax[1].set_xticklabels([a for a, _ in acc][::4], rotation=70, fontsize=7)
ax[1].set_xlabel(r'accepted estimator variant  $[t_0,t_1]$ / passes')
ax[1].set_ylabel(r'$\delta^{(A)}_{\max}$')
ax[1].set_title(f'(b)  Ordering persists across all {len(acc)} accepted\n      estimator variants', fontsize=10, loc='left')
ax[1].legend(frameon=False, fontsize=8)

al = np.linspace(0, 1, 21)
pk = np.array([peak(ds, lin(a)) for a in al])
ax[2].plot(al, pk, 'o-', color='#2ca02c', ms=4, lw=1.6)
ax[2].plot([0], [pk[0]], 'o', color=COL['Var_x'], ms=7)
ax[2].plot([1], [pk[-1]], 'o', color=COL['Var_p'], ms=7)
ax[2].set_xlabel(r'$\alpha$   in   $A_\alpha=(1-\alpha)\,x^2+\alpha\,p^2$')
ax[2].set_ylabel(r'$\delta^{(A_\alpha)}_{\max}$')
ax[2].set_title('(c)  Continuous displacement along a linear\n      Hermitian observable family', fontsize=10, loc='left')
np.savez('linear_family.npz', alpha=al, peak=pk)

plt.tight_layout(); plt.savefig('fig_observable_scan.png', dpi=200)
print('linear family: delta_max from %.5f to %.5f, span %.5f, monotone %s'
      % (pk[0], pk[-1], pk[-1] - pk[0], bool(np.all(np.diff(pk) > 0))))
print('accepted estimator variants:', len(acc))
