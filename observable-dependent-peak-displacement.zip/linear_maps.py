"""
Genuinely linear observation maps for the frequency scan.

Theorem 1 is stated for linear expectation-value observation maps,
M_A(rho) = Tr(rho A).  The variances used so far are not of that form in
general.  However, the potential is even at all times and the initial state is
the ground state, so parity is conserved and the first moments vanish
identically; when <x> = <p> = 0 one has Var_x = <x^2> = Tr(rho x^2) exactly, and
likewise for the momentum.  This script (i) verifies the vanishing of the first
moments and (ii) stores the three independent second moments, which are all
linear in rho:

    A_1 = x^2 ,   A_2 = p^2 ,   A_3 = (xp + px)/2 .

Any A_theta = cos^2(theta) x^2 + sin^2(theta) p^2 is then a linear Hermitian
observation map, and its expectation follows from the stored moments without
re-integrating: <A_theta> = cos^2(theta) <x^2> + sin^2(theta) <p^2>.
"""
import sys, numpy as np
import delta_scan as D
from SM_grid_engine import make_grid, ground_state, potential

def moments(psi, x, dx, k, hbar):
    rho = np.abs(psi)**2; nrm = np.sum(rho)*dx
    ex  = np.sum(x*rho)*dx/nrm
    ex2 = np.sum(x*x*rho)*dx/nrm
    ph  = np.fft.fft(psi); Np = np.sum(np.abs(ph)**2)
    ep  = hbar    * np.sum(np.conj(ph)*k*ph).real / Np
    ep2 = hbar**2 * np.sum(np.conj(ph)*k*k*ph).real / Np
    pp  = np.fft.ifft(hbar*k*np.fft.fft(psi))
    sxp = np.sum(np.conj(psi)*x*pp).real*dx/nrm      # Re<x p> = <(xp+px)/2>
    return ex, ep, ex2, ep2, sxp

def run(deltas):
    x, dx, k = make_grid(D.L, D.M)
    psi0 = ground_state(x, dx, k, potential(D.KIND, x, 1.0, D.BETA), D.HBAR)
    eK = np.exp(-1j*D.HBAR*0.5*k*k*D.DT)
    n = int(D.TWIN/D.DT)
    store = {kk: [] for kk in ('ex','ep','x2','p2','sxp')}
    T = None
    for d in deltas:
        wp = 2.0 + d
        psi = psi0.copy(); ts = []
        cur = {kk: [] for kk in store}
        for i in range(n):
            t = i*D.DT
            O2 = 1.0 + D.A*np.cos(wp*t)
            hV = np.exp(-1j*potential(D.KIND, x, O2, D.BETA)/D.HBAR*D.DT/2)
            psi = hV*psi; psi = np.fft.ifft(eK*np.fft.fft(psi)); psi = hV*psi
            if i % D.REC == 0:
                ex, ep, ex2, ep2, sxp = moments(psi, x, dx, k, D.HBAR)
                ts.append(t)
                for kk, v in zip(('ex','ep','x2','p2','sxp'), (ex, ep, ex2, ep2, sxp)):
                    cur[kk].append(v)
        T = np.array(ts)
        for kk in store: store[kk].append(np.array(cur[kk]))
        print('.', end='', flush=True)
    print()
    return T, {kk: np.array(v) for kk, v in store.items()}

if __name__ == '__main__':
    ds = np.linspace(0.005, 0.165, 41)
    T, S = run(ds)
    np.savez_compressed('moments.npz', delta=ds, t=T, **S)
    print('max |<x>| over the whole scan :', np.abs(S['ex']).max())
    print('max |<p>| over the whole scan :', np.abs(S['ep']).max())
    print('min <x^2> :', S['x2'].min(), '  min <p^2> :', S['p2'].min())
    print('ratio max|<x>| / sqrt(min <x^2>) :', np.abs(S['ex']).max()/np.sqrt(S['x2'].min()))
