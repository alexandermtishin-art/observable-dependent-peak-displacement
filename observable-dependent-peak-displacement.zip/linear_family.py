"""delta_max(theta) for the linear Hermitian family
       A_theta = cos^2(theta) x^2 + sin^2(theta) p^2 ,
   evaluated from the stored second moments without re-integration."""
import sys, numpy as np
import delta_scan as D
from estimator import rate_pa

z=np.load('moments.npz'); ds=z['delta']; t=z['t']
T0,T1,NPASS = 3.0, 13.0, 2

def peak(d,f,half=0.03):
    i=int(np.nanargmax(f)); m=np.abs(d-d[i])<=half
    c=np.polyfit(d[m],f[m],2); return -c[1]/(2*c[0])

def scan(theta, t0=T0, t1=T1, npass=NPASS):
    c,s = np.cos(theta)**2, np.sin(theta)**2
    lam, r2 = [], []
    for i,d in enumerate(ds):
        sig = c*z['x2'][i] + s*z['p2'][i]
        q = rate_pa(t, sig, 2.0+d, t0, t1, npass=npass)
        lam.append(q[0]); r2.append(q[1])
    return np.array(lam), float(np.nanmin(r2))

print('=== delta_max as a function of the linear observation map ===')
print(f"{'theta/pi':>9}{'A_theta':>28}{'delta_max':>12}{'min R2':>9}")
out=[]
for k in range(0,13):
    th=k*np.pi/24
    lam,r2=scan(th)
    p=peak(ds,lam); out.append((th,p,r2))
    lbl = 'x^2' if k==0 else ('p^2' if k==12 else f'{np.cos(th)**2:.3f} x^2 + {np.sin(th)**2:.3f} p^2')
    print(f'{k/24:>9.4f}{lbl:>28}{p:>12.5f}{r2:>9.4f}')
th,p,_=zip(*out)
print(f'\nrange of delta_max over the linear family: {min(p):.5f} … {max(p):.5f}   (span {max(p)-min(p):.5f})')
print('monotone in theta:', all(np.diff(p)>0) or all(np.diff(p)<0))
np.savez('linear_family_theta.npz', theta=np.array(th), peak=np.array(p))
# NOTE: the alpha-parametrised scan used for Fig. 1(c) is written by mkfig.py to
# linear_family.npz. The two files use different parametrisations of the same
# family (alpha = sin^2 theta) and must not share a filename.

print('\n=== envelope check on the two extreme linear maps ===')
import itertools
acc=[]
for t0,t1,npass in itertools.product((2.5,3.0,3.5,4.0),(11.,12.,13.,14.,15.,16.),(1,2,3,4)):
    lx,r2x=scan(0.0,t0,t1,npass); lp,r2p=scan(np.pi/2,t0,t1,npass)
    lm,r2m=scan(np.pi/4,t0,t1,npass)
    if min(r2x,r2p,r2m)<0.98: continue
    acc.append((peak(ds,lx),peak(ds,lm),peak(ds,lp)))
A=np.array(acc)
print('accepted estimator variants:', len(A))
print('  x^2          mean %+.5f  min %+.5f  max %+.5f'%(A[:,0].mean(),A[:,0].min(),A[:,0].max()))
print('  (x^2+p^2)/2  mean %+.5f  min %+.5f  max %+.5f'%(A[:,1].mean(),A[:,1].min(),A[:,1].max()))
print('  p^2          mean %+.5f  min %+.5f  max %+.5f'%(A[:,2].mean(),A[:,2].min(),A[:,2].max()))
ok=np.all((A[:,0]<A[:,1])&(A[:,1]<A[:,2]))
print('  ordering x^2 < (x^2+p^2)/2 < p^2 in every accepted variant:', bool(ok))
print('  smallest separation anywhere: %.5f'%min((A[:,1]-A[:,0]).min(),(A[:,2]-A[:,1]).min()))
