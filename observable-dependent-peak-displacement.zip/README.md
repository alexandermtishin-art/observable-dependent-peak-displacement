# Observable-dependent location of finite-time amplification maxima

Code and data accompanying

> A. M. Tishin, *Observable-Dependent Location of Finite-Time Amplification
> Maxima in Projected Quantum Dynamics*.

Everything needed to regenerate every number, table and figure in Sections 7
and 8 of the paper is contained here, including the stored trajectories, so the
results can be reproduced without repeating the integration.

## What the calculation does

A parametrically driven anharmonic oscillator is integrated on a periodic
position grid,

```
i ħ_eff ∂_t ψ = [ −(ħ_eff²/2) ∂_xx + V(x,t) ] ψ
V(x,t)  = ½ Ω²(t) x² + (β/4) x⁴
Ω²(t)   = Ω₀² [ 1 + A cos(ω_p t) ]
```

with the pump detuning `δ = ω_p − 2Ω₀` as the control parameter. For each `δ`
the Schrödinger equation is integrated **once**, and several scalar readouts are
taken from the same stored trajectory. All readouts are then processed by an
identical estimator with a single common fit window, so that the only thing
differing between them is the observation map.

Two of the readouts, `⟨x²⟩` and `⟨p²⟩`, are linear expectation-value maps
`Tr(ρA)`: the potential is even at every instant and the initial state is the
ground state, so parity is conserved and the first moments vanish (verified
numerically to `5×10⁻¹⁴`). The third, the larger eigenvalue of the covariance
matrix, is a nonlinear functional of the state and is reported separately as an
empirical extension.

The main result is that the location of the maximum of the projected
amplification moves continuously along the linear Hermitian family
`A_α = (1−α) x² + α p²`, from `δ = +0.0692` at `α = 0` to `δ = +0.1073` at
`α = 1`, while the dynamics is held fixed.

## Layout

| File | Purpose |
|---|---|
| `SM_grid_engine.py` | Split-operator grid engine: grid, imaginary-time ground state, evolution with `ħ_eff`, covariance moments in canonical variables |
| `delta_scan.py` | Detuning scan: one integration per `δ`, several readouts from the same trajectory, common estimator and window, sub-grid argmax |
| `estimator.py` | Period-aware rate estimator: cubic spline, analytic antiderivative, exact one-period running average, multi-pass variant |
| `linear_maps.py` | Verifies that the first moments vanish; stores the three independent second moments, all linear in `ρ` |
| `linear_family.py` | Location of the maximum along the same family in the θ parametrisation, evaluated from the stored moments without re-integration; also runs the envelope check on the two extreme members |
| `runner.py` | Staged execution of the coarse and fine scans, with caching |
| `store_signals.py` | Stores raw signals on the fine detuning grid |
| `envelope.py` | Sweep over 96 estimator variants with the acceptance criterion applied |
| `compare_estimators.py` | The three acceptance checks performed when the estimator was changed |
| `robustness.py` | Repetition of the scan at five points in `(A, ħ_eff)` |
| `dtcheck.py` | Time-step convergence control |
| `mkfig.py`, `mkfig_robustness.py` | Figures 1 and 2 of the paper |

Cached results: `coarse.json`, `fine.json`, `robustness.json`,
`linear_family.npz` (the α-parametrised scan written by `mkfig.py` and plotted in
Fig. 1(c)) and `linear_family_theta.npz` (the equivalent θ-parametrised scan
written by `linear_family.py`, with α = sin²θ). Raw stored data: `signals.npz` (readout signals on the fine
detuning grid) and `moments.npz` (first and second moments on the same grid).
Figures are written to `figures/`.

## Reproducing the results

```bash
pip install -r requirements.txt

python runner.py coarse        # coarse detuning scan
python runner.py fine          # fine scan (reads fine_deltas.json)
python store_signals.py        # store raw signals
python linear_maps.py          # first and second moments
python envelope.py             # estimator envelope, 96 variants
python dtcheck.py              # time-step convergence control
python robustness.py A hbar lo hi n Twin    # e.g. 0.20 0.25 0.005 0.165 21 30
python linear_family.py        # delta_max along the linear family
python mkfig.py                # Figure 1
python mkfig_robustness.py     # Figure 2
```

The analysis scripts (`envelope.py`, `linear_family.py`, `mkfig*.py`) read the
stored `.npz` files and do not repeat the integration; they run in a few minutes.
The scanning scripts re-integrate and take longer.

Tested with Python 3.11.

## Reported numbers

Reference estimator (common fit window `[3.0, 13.0]`, two averaging passes):

| readout | `δ_max` |
|---|---|
| `⟨x²⟩` | +0.0689 |
| `σ_max` | +0.0932 |
| `⟨p²⟩` | +0.1070 |

These are the fixed-readout locations produced by `robustness.py`. The endpoints
of the `A_α` family, produced by `linear_family.py`, are `+0.0692` and `+0.1073`;
the two scripts use different parabolic fit windows (half-width 0.03 on the 0.004
detuning grid versus 3.5 grid steps on the 0.008 grid), and the difference of
`3×10⁻⁴` is within the argmax determination uncertainty.

Across the 72 estimator variants passing `R² ≥ 0.98`, the ordering is preserved
without exception and for these three fixed readouts the smallest separation is 0.0062 (the corresponding figure within the `A_α`-family envelope is 0.0092). Across five
points in `(A, ħ_eff)` the common position of the maxima traverses 0.033–0.157
while the separations stay within 0.0204–0.0245 and 0.0093–0.0158.

## Licence and citation

Code and data are released under the MIT licence (see `LICENSE`). If you use
them, please cite the paper and this archive; see `CITATION.cff`.
