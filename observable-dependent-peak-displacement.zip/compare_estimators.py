"""Three acceptance checks after switching to the period-aware estimator:
   (1) new R2 for all three observables; (2) shift of delta_max relative to the
   boxcar values; (3) preservation of the ordering in every common window."""
import sys, numpy as np
import delta_scan as D
from estimator import rate_pa, rate_pa_log

z = np.load('signals.npz'); ds = z['delta']; t = z['t']; OBS = D.OBS
WINS = [(a, b) for a in (2.5, 3.0, 3.5, 4.0) for b in (12., 13., 14., 15., 16.)]

def sweep(fn, t0, t1):
    F, R2, SAT = {}, {}, {}
    for o in OBS:
        r = [fn(t, z[o][i], 2.0 + d, t0, t1) for i, d in enumerate(ds)]
        F[o] = np.array([q[0] for q in r])
        R2[o] = np.array([q[1] for q in r])
        SAT[o] = np.array([q[3] for q in r])
    return F, R2, SAT

def peak(d, f, half=0.03):
    i = int(np.nanargmax(f)); m = np.abs(d - d[i]) <= half
    c = np.polyfit(d[m], f[m], 2); return -c[1] / (2 * c[0])

print('=== check 1: R2 over the whole scan, window 3.0-14.0 ===')
print(f"{'':>10}{'boxcar min R2':>16}{'period-aware min R2':>22}")
_, R2b, _ = sweep(D.rate, 3.0, 14.0)
_, R2p, SATp = sweep(rate_pa, 3.0, 14.0)
for o in OBS:
    print(f'{o:>10}{np.nanmin(R2b[o]):>16.5f}{np.nanmin(R2p[o]):>22.5f}')
print('worst R2 over ALL 20 windows (period-aware):')
worst = {o: 1.0 for o in OBS}
for a, b in WINS:
    _, R2w, _ = sweep(rate_pa, a, b)
    for o in OBS: worst[o] = min(worst[o], np.nanmin(R2w[o]))
print('  ' + '  '.join(f'{o}={worst[o]:.5f}' for o in OBS))
print('  max window spread (3.0-14.0): '
      + '  '.join(f'{o}={np.nanmax(SATp[o]):.3f}' for o in OBS))

print('\n=== check 2: shift of delta_max, window 3.0-14.0 ===')
Fb, _, _ = sweep(D.rate, 3.0, 14.0)
Fp, _, _ = sweep(rate_pa, 3.0, 14.0)
print(f"{'':>10}{'boxcar':>11}{'period-aware':>15}{'shift':>11}")
for o in OBS:
    pb, pp = peak(ds, Fb[o]), peak(ds, Fp[o])
    print(f'{o:>10}{pb:>11.5f}{pp:>15.5f}{pp-pb:>+11.5f}')

print('\n=== check 3: ordering across all 20 common windows (period-aware) ===')
print(f"{'t0':>5}{'t1':>6}" + ''.join(f'{o:>12}' for o in OBS)
      + f"{'spread':>10}{'ordered':>9}")
P = {o: [] for o in OBS}; allok = True
for a, b in WINS:
    Fw, _, _ = sweep(rate_pa, a, b)
    p = [peak(ds, Fw[o]) for o in OBS]
    for o, v in zip(OBS, p): P[o].append(v)
    ok = p[1] < p[0] < p[2]      # Var_x < sigma_max < Var_p
    allok &= ok
    print(f'{a:>5.1f}{b:>6.1f}' + ''.join(f'{v:>12.5f}' for v in p)
          + f'{max(p)-min(p):>10.5f}{("yes" if ok else "NO"):>9}')
P = {o: np.array(v) for o, v in P.items()}
print('\nmean over 20 windows: ' + '  '.join(f'{o}={P[o].mean():+.5f}' for o in OBS))
print('std  over 20 windows: ' + '  '.join(f'{o}={P[o].std():.5f}' for o in OBS))
sp = np.array([max(P[o][i] for o in OBS) - min(P[o][i] for o in OBS)
               for i in range(len(WINS))])
print(f'spread over windows: min {sp.min():.5f}  max {sp.max():.5f}')
print('ordering preserved in every window:', allok)
